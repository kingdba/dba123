col cf for 9999 head "Control|File|backups"
col df for 9999 head "Data File|full|backups"
col elapsed_seconds for 99999 heading "Elapsed|Seconds"
col i0 for 9999 head "Data File|incr(0)|backups"
col i1 for 9999 head "Data File|incr(1)|backups"
col l for  9999 head "Archivelog|backups"
col output_mbytes for 9999999 head "Outbut|MBytes"
col status for a10 trunc head "Backup|status"
col time_taken_display for a10 head "Time|Taken"
col output_instance for 9999 head "Instance|number"
col dow for a10 head "Day|of|week"
col input_type for a12 head "Input|Type"
col start_time for a20 head "Start|time"
col end_time for a20 head "End|time"

prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42


select
--a.session_recid, a.session_stamp,
to_char(a.start_time, 'yyyy-mm-dd hh24:mi:ss') start_time,
to_char(a.end_time, 'yyyy-mm-dd hh24:mi:ss') end_time,
(a.output_bytes/1024/1024) output_mbytes, a.status, a.input_type,
decode(to_char(a.start_time, 'd'), 1, 'Sunday', 2, 'Monday', 3, 'Tuesday', 4, 'Wednesday', 5, 'Thursday', 6, 'Friday', 7, 'Saturday') dow,
a.elapsed_seconds, a.time_taken_display, tmp1.cf, tmp1.df, tmp1.i0, tmp1.i1, tmp1.l, tmp2.inst_id output_instance
from v$rman_backup_job_details a
  left outer join (select b.session_recid, b.session_stamp,
                     sum(case when b.controlfile_included = 'YES' then b.pieces else 0 end) CF,
                     sum(case when b.controlfile_included = 'NO'
                               and b.backup_type||b.incremental_level = 'D' then b.pieces else 0 end) DF,
                     sum(case when b.backup_type||b.incremental_level = 'D0' then b.pieces else 0 end) I0,
                     sum(case when b.backup_type||b.incremental_level = 'I1' then b.pieces else 0 end) I1,
                     sum(case when b.backup_type = 'L' then b.pieces else 0 end) L
                   from
                     v$backup_set_details b
                     join v$backup_set c on c.set_stamp = b.set_stamp and c.set_count = b.set_count
                   where c.input_file_scan_only = 'NO'
                   group by b.session_recid, b.session_stamp) tmp1
    on tmp1.session_recid = a.session_recid and tmp1.session_stamp = a.session_stamp
  left outer join (select c.session_recid, c.session_stamp, min(inst_id) inst_id
                   from gv$rman_output c
                   group by c.session_recid, c.session_stamp) tmp2 on tmp2.session_recid = a.session_recid 
and tmp2.session_stamp = a.session_stamp where a.start_time >= trunc (sysdate-&&l_days)
order by a.start_time
/
