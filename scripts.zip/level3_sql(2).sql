--#######################
--Level 3 script - AWR
--#######################

--Scope: SQL, history of executions
clear col
clear brea
clear comp
set linesize 200
set pagesize 1000

prompt Enter sql_id 
prompt
accept l_sqlid prompt 'SQL Id:' 
prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

column event format a30
column program format a40
column module format a40
column sql_id format a14
column ash_secs format 99999999
col snap_id for 99999 head "Snap|id"
col s_time for a12 head "Snap|end time"
col elapsed_t for a8 head "Elap|secs"
col sql_id for a15 head "Sql|Id"
col plan_hash_value for a9 head "Plan|hash|value"
col cpu_t for a8 head "Cpu|secs"
col user_io for a8 head "IO|secs"
col java_s for a5 head "Java|secs"
col pl_s for a5 head "PlSQL|secs"
col app_s for a5 head "App|secs"
col sec_per_exec for a8 head "Secs|per|exec"
col executions_delta for a5 head "Exec"
col physical_read_requests_delta for a8 head "Ph|reads"
col physical_read_bytes_delta for a5 head "Ph|reads|Mb"
col physical_write_requests_delta for a6 head "Ph|writes"         
col physical_write_bytes_delta for a5 head "Ph|writes|Mb"   
col sorts_delta for a5 head "Sorts"
col buffer_gets_delta for a10 head "Buffer|gets"
col disk_reads_delta for a8 head "Disk|reads"
col read_bytes_sec for a5 head "Mb Read|per Sec"
col cluster_w for a5 head "CRS|secs"
col conc_s for a8 head "Cncy|secs"
col rows_processed for a8 head "Rows|proc"
col fetches for a8 head "Fetches"
col rows_exec for a5 head "Rows|per|exec"

break on sql_id on plan_hash_value

select sql_id, to_char(plan_hash_value) plan_hash_value
,a.snap_id
,to_char(b.end_interval_time,'DD-MON-YY hh24') s_time
,to_char(round(elapsed_time_delta/1000000,2)) elapsed_t
,to_char(round(cpu_time_delta/1000000,2)) cpu_t
,to_char(round(iowait_delta/1000000,2)) user_io
,to_char(round(clwait_delta/1000000,2)) cluster_w
,to_char(round(ccwait_delta/1000000,2)) conc_s
,to_char(round(plsexec_time_delta/1000000,2)) pl_s
,to_char(round(apwait_delta/1000000,2)) app_s
--,to_char(round(javexec_time_delta/1000000, 2)) java_s
,to_char(decode (executions_delta,0,round(elapsed_time_delta/1000000,2),round(elapsed_time_delta/1000000/executions_delta,2))) Sec_Per_Exec
,to_char(rows_processed_delta) rows_processed
,to_char(fetches_delta) fetches
,to_char(executions_delta) executions_delta
,to_char(sorts_delta) sorts_delta
,to_char(buffer_gets_delta) buffer_gets_delta
,to_char(disk_reads_delta) disk_reads_delta
,to_char(physical_read_requests_delta) physical_read_requests_delta
--,to_char(physical_read_bytes_delta/1024/1024) physical_read_bytes_delta
,to_char(physical_write_requests_delta) physical_write_requests_delta         
,to_char(round(rows_processed_delta/executions_delta)) rows_exec
--,to_char(physical_write_bytes_delta/1024/1024) physical_write_bytes_delta   
--,to_char(decode(rows_processed_delta,0,buffer_gets_delta,round(buffer_gets_delta/rows_processed_delta))) Buf_Per_Rows
--,to_char(round(physical_read_bytes_delta/(iowait_delta/1000000),2)/1024/1024) read_bytes_sec
--,upper(sql_text)
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
and a.dbid = b.dbid
and sql_id = ('&&l_sqlid')
and trunc(b.end_interval_time) >= trunc (sysdate-&&l_days)
order by sql_id, a.snap_id
/