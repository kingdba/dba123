--####################
--Level 2 script - CPU
--####################

--Scope: daily CPU usage per hosted instance, for a given month

clear columns
clear computes
col s_time for a11 head "Day of|Month" justify left
break on s_time skip page
column entity_name format a20 heading "Instance|name" justify left
column avg_cpu_cores format 99.99 heading "Avg Cores|per sec" justify left
column max_cpu_cores format 99.99 heading "Max Cores|per sec" justify left
set linesize 200
set pagesize 1000

prompt
prompt ############################
prompt Level 2 - CPU daily report
prompt ############################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt Enter month and year. Format MON-YYYY
prompt Example: SEP-2015
accept l_myear prompt 'Month and Year:'


select to_char(collection_time,'DD-MON-YYYY') s_time, substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,avg(case when metric_column_name = 'cpuusage_ps' then round(avg_value/100,1) end) avg_cpu_cores
,avg(case when metric_column_name = 'cpuusage_ps' then round(max_value/100,1) end) max_cpu_cores
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and b.host_name = ('&&l_hostname')
and metric_group_name = 'instance_efficiency'
and metric_column_name = 'cpuusage_ps'
and collection_time >=  to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < add_months(to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss'),1)
group by to_char(collection_time,'DD-MON-YYYY'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
having avg(case when metric_column_name = 'cpuusage_ps' then round(avg_value/100,1) end) > 0
order by to_date(to_char(collection_time,'DD-MON-YYYY'),'DD-MON-YYYY'), avg_cpu_cores desc
/
