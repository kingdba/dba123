clear col comp bre

col instance_number for 99 head "Inst|Id"
col begin_interval_time for a25 head "Begin|interval|time"
col component for a30 head "Component"
col user_specified_size for a10 head "User|specified|size(Mb)"
col current_size for a8 head "Current|size(Mb)"
col min_size for a8 head "Min|size(Mb)"
col max_size for a8 head "Max|size(Mb)"
col oper_count for 99999 head "Oper|count"
col last_oper_type for a15 head "Last|oper|type"
col last_oper_mode for a15 head "Last|oper|mode"
col last_oper_time for a20 head "Last|oper|time"

brea on instance_number on begin_interval_time ski 1

prompt Enter instance number (default 1) 
prompt
accept l_inst prompt 'Instance number [1]:' default 1
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

select a.instance_number, b.begin_interval_time, component, to_char(user_specified_size/1024/1024) user_specified_size,
to_char(current_size/1024/1024) current_size, to_char(min_size/1024/1024) min_size, 
to_char(max_size/1024/1024) max_size, oper_count, last_oper_type, last_oper_mode, last_oper_time
from dba_hist_mem_dynamic_comp a, dba_hist_snapshot b
where 
a.snap_id = b.snap_id
and a.dbid = b.dbid
and a.instance_number = b.instance_number
and b.begin_interval_time >= trunc(sysdate - &&l_days)
and a.component in ('SGA Target','DEFAULT buffer cache', 'shared pool')
and (a.instance_number = &&l_inst or &&l_inst = 0)
and to_char(begin_interval_time,'HH24') = '10'
order by 1, 2, 3
/