-- ####################
-- Level 3 SQL Id Count
-- ####################

clear col bre comp

set linesize 200
set pagesize 1000

col force_matching_signature for a20 head "Force|matching|signature"
col s_time for a15 head "Snap|time"
col executions for 9999999999 head "Sql|execs"
col cpu_t for 9999999999.99 head "Cpu|secs"
col elapsed_t for 9999999999.99 head "Elapsed|secs"
col user_io for 9999999999.99 head "user i/o|secs"
col plan_hash_value for a15 head "Plan|hash|value"
col sec_per_exec for 99999999.9999 head "Secons|per|execution"
col buffer_gets for 9999999999 head "Buffer|gets"
col rows_processed for 9999999999 head "Rows|processed"
col disk_r for 9999999999 head "Disk|reads"

brea on force_matching_signature on plan_hash_value ski 1

prompt
prompt ###################################################################
prompt Daily counts for Sql_id
prompt Script uses AWR Begin Interval Time, thus
prompt counts apply to the time between current row and the row below
prompt ###################################################################
prompt 


prompt Enter matching signature
prompt
accept l_signature prompt 'Matching Signature:' 
prompt
prompt Enter Day of Month. Format DD-MON-YYYY
prompt Example: 01-SEP-2015
accept l_myear prompt 'Day of Month:'
prompt

select to_char(force_matching_signature) force_matching_signature
,to_char(plan_hash_value) plan_hash_value
,to_char(begin_interval_time,'DD-MON-YYYY hh24') s_time 
,sum(executions_delta) executions
,round(sum(elapsed_time_delta)/1000000,2) elapsed_t
,round(sum(iowait_delta/1000000), 2) user_io
,round(sum(cpu_time_delta)/1000000,2) cpu_t
,round(sum(buffer_gets_delta)) buffer_gets
,round(sum(disk_reads_delta)) disk_r
,round(sum(rows_processed_delta)) rows_processed
,decode(sum(executions_delta),0,round(sum(elapsed_time_delta)/1000000,2),round(sum(elapsed_time_delta)/1000000/sum(executions_delta),4)) sec_per_exec
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and b.instance_number=b.instance_number
and a.force_matching_signature = ('&&l_signature')
and begin_interval_time >=  to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and begin_interval_time < to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss')+1
group by force_matching_signature, plan_hash_value, to_char(begin_interval_time,'DD-MON-YYYY hh24')
order by to_date(to_char(begin_interval_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), plan_hash_value
/

