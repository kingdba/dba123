cl scr
clear col brea comp

--Scope: SQL, top writers. 11g


prompt
prompt ###########################
prompt Top 10 Writers AWR monthly
prompt ###########################
prompt

clear columns
clear computes
clear breaks

col s_time for a12 head "Month of|Year" justify left
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|Secs"
col ph_writes for 999999999999 head "Physical|Writes" justify left
col direct_writes for 9999999999 head "Direct|Writes"

--col rnk for 99 head "Group|Ranking"
col rnk noprint

break on s_time ski page

select * from (
select to_char(begin_interval_time, 'MON-YYYY') s_time, sql_id
, sum(physical_write_requests_delta) ph_writes
, sum(direct_writes_delta) direct_writes 
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, sum(buffer_gets_delta) buff_gets
, sum(cpu_time_delta)/1000000 cpu_time
, rank() over (partition by to_char(begin_interval_time, 'MON-YYYY') order by sum(physical_write_requests_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
--and begin_interval_time between to_date('07-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') 
--and to_date('14-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') --date filter
group by to_char(begin_interval_time, 'MON-YYYY'), sql_id
having sum(physical_write_requests_delta) > 0
order by to_date(to_char(begin_interval_time, 'MON-YYYY'),'MON-YYYY'), ph_writes desc)
where rnk <=10
/


prompt
prompt ###############################
prompt Top 10 Writers AWR last 7 days
prompt ###############################
prompt

col s_time for a12 head "Day of|Month" justify left

select * from (
select to_char(begin_interval_time, 'DD-MON-YYYY') s_time, sql_id
, sum(physical_write_requests_delta) ph_writes
, sum(direct_writes_delta) direct_writes 
, sum(cpu_time_delta)/1000000 cpu_time
, sum(buffer_gets_delta) buff_gets
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, rank() over (partition by to_char(begin_interval_time, 'DD-MON-YYYY') order by sum(physical_write_requests_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
and begin_interval_time >= trunc(sysdate)-7
group by to_char(begin_interval_time, 'DD-MON-YYYY'), sql_id
having sum(physical_write_requests_delta) > 0
order by to_date(to_char(begin_interval_time, 'DD-MON-YYYY'),'DD-MON-YYYY'), ph_writes desc)
where rnk <=10
/

prompt
prompt #############################
prompt Top 10 Writers - Cursor Cache
prompt #############################
prompt

clear col brea comp

col inst_id for 99 head "Instance|number"
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|Secs"
col ph_writes for 999999999999 head "Physical|Writes" justify left
col direct_writes for 9999999999 head "Direct|Writes"

--Cursor Cache

select * from (select
sql_id
, sum(physical_write_requests) ph_writes
, sum(direct_writes) direct_writes
, sum(disk_reads) disk_reads
, sum(physical_read_requests) ph_reads 
, sum(buffer_gets) buff_gets
, sum(cpu_time)/1000000 cpu_time
from gv$sql
group by sql_id
order by ph_writes desc)
where rownum <=10
/

prompt
prompt ######################################
prompt Top 10 Writers - Active SQL Monitoring
prompt ######################################
prompt

col inst_id for 9999
col username for a18
col sid for 99999
col sql_id for a15
col buffer_gets for 999999999999999999
col cpu_secs for 99999.99
col disk_reads for 9999999999
col direct_writes for 9999999999
col physical_read_requests for 9999999999
col physical_write_requests for 9999999999

select * from (
select inst_id, username, sid, sql_id, buffer_gets, round(cpu_time/1000000,1) cpu_secs, 
disk_reads, direct_writes, physical_read_requests, physical_write_requests
from gv$sql_monitor
where status = 'EXECUTING'
order by physical_write_requests desc)
where rownum <=10
/

prompt
prompt ######################################
prompt Top possible Ph Writes TMP - Sessions
prompt ######################################
prompt

prompt
prompt --session statistics
prompt

clear col brea comp

col inst_id for 99 head "Inst|id"
col sid for 99999 head "sid"
col serial# for 99999999 head "serial#"
col username for a10 head "Username"
col program for a35 head "Program"
col machine for a20 head "Client|Pc"
col osuser for a10 head "Osuser"
col pwd for 9999999999 head  "phy writes|direct"
col pwdt for 9999999999 head "phy writes|direct temp"
col sd for 9999999999 head "sorts|disk"
col wem for 999999999 head "workarea|multipass"

select * from (select a.inst_id, a.sid, a.serial#, a.username, a.program, a.machine, a.osuser
,nvl(max(case when c.name = 'physical writes direct' then b.value end),0) pwd
,nvl(max(case when c.name = 'physical writes direct temporary tablespace' then b.value end),0) pwdt
,nvl(max(case when c.name = 'sorts (disk)' then b.value end),0) sd
,nvl(max(case when c.name = 'workarea executions - multipass' then b.value end),0) wem
from gv$session a, gv$sesstat b, v$statname c
where
a.inst_id = b.inst_id
and a.sid=b.sid
and c.statistic#=b.statistic#
and c.name in ('physical writes direct temporary tablespace','physical writes direct','sorts (disk)','workarea executions - multipass')
and b.value>0
and a.username is not null
group by a.inst_id, a.sid, a.serial#, a.username, a.program, a.machine, a.osuser
order by pwdt desc)
where rownum <= 10
/

prompt
prompt --session events
prompt --in SECONDS

prompt

col dpw for 99999999 head  "direct path|write"
col dpwt for 99999999 head  "direct path|write temp"
col dpr for 99999999 head  "direct path|read"
col dprt for 99999999 head  "direct path|read temp"

select * from (select a.inst_id, a.sid, a.serial#, a.username, a.program, a.machine, a.osuser
,nvl(max(case when b.event = 'direct path write' then b.time_waited/100 end),0) dpw
,nvl(max(case when b.event = 'direct path read' then b.time_waited/100 end),0) dpr
,nvl(max(case when b.event = 'direct path write temp' then b.time_waited/100 end),0) dpwt
,nvl(max(case when b.event = 'direct path read temp' then b.time_waited/100 end),0) dprt
from gv$session a, gv$session_event b
where
a.inst_id = b.inst_id
and a.sid=b.sid
and b.event in ('direct path write','direct path read','direct path write temp','direct path read temp')
and a.username is not null
group by a.inst_id, a.sid, a.serial#, a.username, a.program, a.machine, a.osuser
order by dpwt desc)
where rownum <= 10
/

prompt
prompt --ASH reference, last 2 hours (to match with script above)
prompt --mind session may have disconnected
prompt

clear col brea comp

col sid for 999999  head "Db|Sid"
col sn for 999999  head "Db|Serial#"
col wait_class for a15 head "Wait|Class"
col event for a35 head "Wait|Event"
col sql_id for a20 head "Sql|id"
col ash_secs for 9999999999 head "ASH|seconds"
col max_pga for 99999999 head "Pga|Mb"
col max_temp for 99999999 head "Temp|Mb"

break on inst_id on sid on sn skip 1 

select inst_id, session_id sid, session_serial# sn, wait_class, event, sql_id, 
max(pga_allocated)/1024/1024 max_pga, max(temp_space_allocated)/1024/1024 max_temp, sum(1) ash_secs
from gv$active_session_history 
where event in ('direct path write','direct path read','direct path write temp','direct path read temp')
--and inst_id = 2   
--and session_id = 370     
--and session_serial# = 23103
and sample_time >= sysdate -2/24
group by inst_id, session_id, session_serial#, wait_class, event, sql_id
having sum(1) >= 10
order by inst_id, session_id, session_serial#, ash_secs desc
/


prompt
prompt ####################
prompt Top Block Changers
prompt ####################
prompt

clear col brea comp

col inst_id for 99
col username for a15
col program for a40
col module for a35
col sql_id for a15
col physical_reads for 9999999999
col block_changes for 9999999999

select * from (
select b.inst_id, b.username, b.logon_time, b.program, b.module, b.sql_id, 
--b.sid, 
a.physical_reads, a.block_changes    
from gv$sess_io a, gv$session b
where a.inst_id = b.inst_id
and a.sid = b.sid
and username is not null
order by block_changes desc)
where rownum <= 10
/

prompt
prompt ############################
prompt Top Segments Block Changers
prompt ############################
prompt

clear col bre comp
col s_time for a20 head "Snap|time"
col owner for a15 head "Owner"
col object_name for  a30 head "Object|name"
col bch for 999999999999 head "Block|changes"
--col rnk for 99 head "Group|Ranking"
col rnk noprint

break on s_time skip 1

prompt 
prompt Monthly
prompt 

select * from (
select to_char(begin_interval_time, 'MON-YYYY') s_time, b.owner, b.object_name, sum(db_block_changes_delta) bch,
rank() over (partition by to_char(begin_interval_time, 'MON-YYYY') order by sum(db_block_changes_delta) desc) rnk
from dba_hist_seg_stat a, dba_hist_seg_stat_obj b, dba_hist_snapshot c
where c.snap_id = a.snap_id
and a.obj# = b.obj#
and a.dataobj# = b.dataobj#
group by to_char(begin_interval_time, 'MON-YYYY'), b.owner, b.object_name
order by to_date(to_char(begin_interval_time, 'MON-YYYY'),'MON-YYYY'), bch desc)
where rnk <=10
/

prompt 
prompt Last 47..48 hours
prompt 

select * from (
select to_char(begin_interval_time, 'DD-MON-YYYY') s_time, b.owner, b.object_name, sum(db_block_changes_delta) bch,
rank() over (partition by to_char(begin_interval_time, 'DD-MON-YYYY') order by sum(db_block_changes_delta) desc) rnk
from dba_hist_seg_stat a, dba_hist_seg_stat_obj b, dba_hist_snapshot c
where c.snap_id = a.snap_id
and a.obj# = b.obj#
and a.dataobj# = b.dataobj#
and begin_interval_time >= sysdate-48/24
group by to_char(begin_interval_time, 'DD-MON-YYYY'), b.owner, b.object_name
order by to_date(to_char(begin_interval_time, 'DD-MON-YYYY'),'DD-MON-YYYY'), bch desc)
where rnk <=10
/


prompt 
prompt Last 2..3 hours
prompt 

select * from (
select to_char(begin_interval_time, 'DD-MON-YYYY hh24') s_time, b.owner, b.object_name, sum(db_block_changes_delta) bch,
rank() over (partition by to_char(begin_interval_time, 'DD-MON-YYYY hh24') order by sum(db_block_changes_delta) desc) rnk
from dba_hist_seg_stat a, dba_hist_seg_stat_obj b, dba_hist_snapshot c
where c.snap_id = a.snap_id
and a.obj# = b.obj#
and a.dataobj# = b.dataobj#
and begin_interval_time >= sysdate-3/24
group by to_char(begin_interval_time, 'DD-MON-YYYY hh24'), b.owner, b.object_name
order by to_date(to_char(begin_interval_time, 'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), bch desc)
where rnk <=10
/


prompt
prompt ################################
prompt Top possible SQL Block Changers
prompt ################################
prompt

col sql_id for a15
col rows_processed for 999999999
col buffer_gets for 99999999999
col sql_text for a80

select * from (
select sql_id, sum(rows_processed) rows_processed, sum(buffer_gets) buffer_gets, substr(sql_text,1,80) sql_text
from gv$sql 
where command_type in (2,6,7)  --insert, update, delete
group by sql_id, substr(sql_text,1,80)
order by 2 desc)
where rownum <=20
/

prompt
prompt ###############
prompt Top 20 Segments 
prompt ###############
prompt

col owner for a15
col object_type for a10
col object_name for a30
col statistic_name for a30
col value for a20

select owner, object_type, object_name, statistic_name, to_char(value) value from (
select owner, object_type, object_name, statistic_name, sum(value) value
from gv$segment_statistics
where statistic_name like '%write%'
group by owner, object_type, object_name, statistic_name
order by value desc)
where rownum <=20
/

