--#######################
--Level 3 script - DBTime
--#######################

--Scope: DB time, wait class

clear col
clear brea
clear comp
set linesize 200
set pagesize 1000

column event format a35
column ash_secs format 99999999

prompt Enter instance number (default 1, 0 for all instances)
prompt
accept l_inst prompt 'Instance number [1]:' default 1 
prompt Enter wait class (default User I/O) 
prompt
accept l_wclass prompt 'Wait Class:' default 'User I/O'
prompt
prompt Enter target date. Format DD-MON-YYYY
prompt Example: 01-SEP-2015
accept l_date prompt 'Target date:'

select --+parallel(a,8,1)
event, sum(10) ash_secs
from dba_hist_active_sess_history a
where wait_class = ('&&l_wclass')
and trunc(sample_time) =  to_date(('&&l_date'), 'DD-MON-YYYY')
and (a.instance_number = &&l_inst or &&l_inst = 0)
group by event
having sum (10) >= 60
order by ash_secs desc
/
