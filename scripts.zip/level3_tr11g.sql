--Level 3 top readers
--11g ONLY

prompt
prompt ###########################
prompt Top 10 Readers AWR monthly
prompt ###########################
prompt

clear columns
clear computes
clear breaks

--Scope: SQL, top readers

col s_time for a12 head "Month of|Year" justify left
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|Secs"
--col rnk for 99 head "Group|Ranking"
col rnk noprint

break on s_time ski page

select * from (
select to_char(begin_interval_time, 'MON-YYYY') s_time, sql_id
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, sum(buffer_gets_delta) buff_gets
, sum(cpu_time_delta)/1000000 cpu_time
, rank() over (partition by to_char(begin_interval_time, 'MON-YYYY') order by sum(disk_reads_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
--and begin_interval_time between to_date('07-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') 
--and to_date('14-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') --date filter
group by to_char(begin_interval_time, 'MON-YYYY'), sql_id
having sum(disk_reads_delta) > 0
order by to_date(to_char(begin_interval_time, 'MON-YYYY'),'MON-YYYY'), disk_reads desc)
where rnk <=10
/

prompt
prompt ##############################
prompt Top 10 Readers AWR last 7 days
prompt ##############################
prompt

col s_time for a12 head "Day of|Month" justify left

select * from (
select to_char(begin_interval_time, 'DD-MON-YYYY') s_time, sql_id
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, sum(buffer_gets_delta) buff_gets
, sum(cpu_time_delta)/1000000 cpu_time
, rank() over (partition by to_char(begin_interval_time, 'DD-MON-YYYY') order by sum(disk_reads_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
and begin_interval_time >= trunc(sysdate)-7
group by to_char(begin_interval_time, 'DD-MON-YYYY'), sql_id
having sum(disk_reads_delta) > 0
order by to_date(to_char(begin_interval_time, 'DD-MON-YYYY'),'DD-MON-YYYY'), disk_reads desc)
where rnk <=10
/

prompt
prompt #############################
prompt Top 10 Readers - Cursor Cache
prompt #############################
prompt

clear col brea comp

col inst_id for 99 head "Instance|number"
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|Secs"

--Cursor Cache

select * from (select
sql_id
, sum(disk_reads) disk_reads
, sum(physical_read_requests) ph_reads 
, sum(buffer_gets) buff_gets
, sum(cpu_time)/1000000 cpu_time
from gv$sql
group by sql_id
order by disk_reads desc)
where rownum <=10
/

prompt
prompt ######################################
prompt Top 10 Readers - Active SQL Monitoring
prompt ######################################
prompt

col inst_id for 9999
col username for a15
col sid for 99999
col sql_id for a15
col buffer_gets for 999999999999999999
col cpu_secs for 99999.99
col disk_reads for 9999999999
col direct_writes for 9999999999
col physical_read_requests for 9999999999
col physical_write_requests for 9999999999

select * from (
select inst_id, username, sid, sql_id, buffer_gets, round(cpu_time/1000000,1) cpu_secs, 
disk_reads, direct_writes, physical_read_requests, physical_write_requests
from gv$sql_monitor
where status = 'EXECUTING'
order by disk_reads desc)
where rownum <=10
/

prompt
prompt ###############
prompt Top 20 Segments 
prompt ###############
prompt

col owner for a15
col object_type for a10
col object_name for a30
col statistic_name for a30
col value for a20

select owner, object_type, object_name, statistic_name, to_char(value) value from (
select owner, object_type, object_name, statistic_name, sum(value) value
from gv$segment_statistics
where statistic_name like '%read%'
group by owner, object_type, object_name, statistic_name
order by value desc)
where rownum <=20
/

