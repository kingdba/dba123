--####################
--Level 2 script - CPU
--####################

--Scope: current day CPU usage per hosted instance

clear col bre comp

col s_time for a15 head "Day of|Month" justify left

column entity_name format a10 heading "Instance|name" justify left
column avg_cpu_cores format 99.99 heading "Avg Cores|per sec" justify left
column max_cpu_cores format 99.99 heading "Max Cores|per sec" justify left

--compute sum of avg_cpu_cores on s_time
--compute sum of max_cpu_cores on s_time

bre on entity_name

set linesize 200
set pagesize 1000

prompt
prompt ############################
prompt Level 2 - CPU daily report
prompt ############################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt Enter db name.
prompt Example: pjdel
accept l_dbname prompt 'Database name:'

select substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,to_char(collection_time,'DD-MON-YYYY hh24') s_time
,avg(case when metric_column_name = 'cpuusage_ps' then round(value/100,1) end) avg_cpu_cores
,max(case when metric_column_name = 'cpuusage_ps' then round(value/100,1) end) max_cpu_cores
from  sysman.gc$metric_values a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and a.entity_name like ('&&l_dbname%')
and b.host_name = ('&&l_hostname')
and metric_group_name = 'instance_efficiency'
and metric_column_name = 'cpuusage_ps'
and collection_time >=  trunc(sysdate)
group by to_char(collection_time,'DD-MON-YYYY hh24'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
--having avg(case when metric_column_name = 'cpuusage_ps' then round(value/100,1) end) > 0
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), avg_cpu_cores desc
/
