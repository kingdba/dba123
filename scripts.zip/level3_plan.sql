clear col bre comp

col sql_id for a15
col child_number for 9999
col plan_hash_value for a20

prompt
prompt ###############
prompt SQL PLan
prompt ###############
prompt

accept l_sql_id char prompt 'sql_id:'

prompt
prompt ################################################
prompt SQL_ID in local instance
prompt Use for inputs below 
prompt If nor rows are returned. Run level3_sqlw.sql
prompt to determine which instance to connect to
prompt ################################################
prompt

select sql_id, child_number, to_char(plan_hash_value) plan_hash_value
from v$sql
where sql_id='&&l_sql_id'
and loaded_versions > 0
order by 1, 2
/

accept l_child char prompt 'Child # [0]:' default 0
accept l_for char prompt 'Format [typical]:' default 'typical'

select t.*
from v$sql s, table(dbms_xplan.display_cursor(s.sql_id, s.child_number, format => '&&l_for +peeked_binds')) t 
where sql_id='&&l_sql_id'
and child_number='&&l_child'
and loaded_versions > 0
/
