--#################################
--Level 2 script - IO exadata Cell
--#################################

--Scope: daily metrics for exadata storage per database

clear col bre comp

set linesize 200
set pagesize 1000

col s_time for a20 head "Snap|time"
col target_name for a20 head "Target|Name"
col avg_io_load for 99.00 head "Avg|IO Load"
col iops for 9999999999 head "IO Req|per sec"
col pct for 9999 head "I/O|Utilization (%)"
col target_name for a20 head "Target|Name"
col avg_io_load for 999.00 head "Avg|IO Load"
col max_io_load for 999.00 head "Max|IO Load"
col avg_iops for 9999.99 head "Avg|IOPS"
col max_iops for 9999.99 head "Max|IOPS"

bre on s_time ski page

prompt
prompt ############################
prompt Level 2 - Cell Daily report
prompt ############################
prompt
prompt Enter exadata cell cluster name below. 
prompt Example: xeg2celadm
prompt
accept l_cellname prompt 'Host name:'
prompt
prompt Enter Day of Month. Format DD-MON-YYYY
prompt Example: 01-SEP-2015
accept l_myear prompt 'Day of Month:'

-- daily
-- samples per day (1 x day x storage_cell_count)

select to_char(collection_time,'DD-MON-YYYY hh24') s_time, key_part_1 target_name 
,round(avg(case when metric_column_label = 'I/O Requests per Second (IO/Sec)' then avg_value end),2) avg_iops
,round(avg(case when metric_column_label = 'I/O Requests per Second (IO/Sec)' then max_value end),2) max_iops
,round(avg(case when metric_column_label = 'Average I/O Load' then avg_value end),2) avg_io_load
,round(avg(case when metric_column_label = 'Average I/O Load' then max_value end),2) max_io_load
--,round(avg(case when metric_column_label = 'I/O Utilization (%)' then avg_value end),2) pct
from sysman.gc$metric_values_daily
where metric_group_name = 'IORMDB_Metric'
and metric_column_label in ('Average I/O Load','I/O Requests per Second (IO/Sec)','I/O Utilization (%)' )
--and collection_time >= sysdate -7
--and entity_name like 'xeg2cel%'
and collection_time >=  to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss')+1
and entity_name like '&&l_cellname%'
group by key_part_1, to_char(collection_time,'DD-MON-YYYY hh24')
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), avg_iops desc
/
