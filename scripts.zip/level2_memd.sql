--###################################
--Level 2 script - Memory and DB Size
--###################################

--Scope: Daily Memory and DB Size metrics per hosted instance

clear col bre comp

column s_time format a11 heading "Month of|Year" justify left

break on s_time skip page

column entity_name format a20 heading "Instance|name" justify left
col db_allocated_gb for 9999999 head "DB Alloc|Gb" justify left
col db_used_gb for 9999999 head "DB Used|Gb" justify left
col instance_mem_gb for 999.99 head "Inst|Mem Gb" justify left

set linesize 200
set pagesize 1000

prompt
prompt ########################################
prompt Level 2 - Mem and DB size daily report
prompt ########################################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt Enter month and year. Format MON-YYYY
prompt Example: SEP-2015
accept l_myear prompt 'Month and Year:'


select to_char(collection_time,'DD-MON-YYYY') s_time, substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,avg(case when metric_column_name = 'ALLOCATED_GB' then avg_value end) db_allocated_gb
,avg(case when metric_column_name = 'USED_GB' then avg_value end) db_used_gb
,avg(case when metric_column_name = 'total_memory' then avg_value/1024 end) instance_mem_gb
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and b.host_name = ('&&l_hostname')
and metric_group_name in ('DATABASE_SIZE','memory_usage')
and metric_column_name in ('ALLOCATED_GB','USED_GB','total_memory')
and collection_time >=  to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < add_months(to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss'),1)
group by to_char(collection_time,'DD-MON-YYYY'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by to_date(to_char(collection_time,'DD-MON-YYYY'),'DD-MON-YYYY'), instance_mem_gb desc
/