--####################
--Level 2 script - CPU
--####################

--Scope: Avg yearly CPU usage per hosted instance

clear columns
clear computes
column s_time format a10 heading "Month of|Year" justify left
break on s_time skip 1
column entity_name format a20 heading "Instance|name" justify left
column avg_cpu_cores format 99.99 heading "Avg Cores|per sec" justify left
column max_cpu_cores format 99.99 heading "Max Cores|per sec" justify left
set linesize 200
set pagesize 1000

prompt
prompt ############################
prompt Level 2 - CPU yearly report
prompt ############################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt

select substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,avg(case when metric_column_name = 'cpuusage_ps' then round(avg_value/100,1) end) avg_cpu_cores
,avg(case when metric_column_name = 'cpuusage_ps' then round(max_value/100,1) end) max_cpu_cores
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and b.host_name = ('&&l_hostname')
and metric_group_name = 'instance_efficiency'
and metric_column_name = 'cpuusage_ps'
and collection_time >= add_months(trunc(sysdate,'MM'),-12 )
group by substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by avg_cpu_cores desc
/
