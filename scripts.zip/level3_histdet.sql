clear bre comp col

set null 0

brea on owner on table_name on last_analyzed

col table_name for a20 head "Table|name"
col last_analyzed for a20 head "Last|analyzed"
col sample_size for a10 head "Sample|size"
col column_name for a25 head "Column|name"
col histogram for a20 head "Histogram"
col num_distinct for 9999999999 head "Num|distinct"
col num_nulls for 9999999999 head "Num|nulls"
col num_buckets for 999 head "Num|buckets"
col user_stats for a5 head "User|manual|stats"
col avg_col_len for 99999 head "Avg row|length"
col owner for a10 head "Owner"
col equality_preds for 99999999 head "Equality|preds"
col equijoin_preds for 99999999 head "Equijoin|preds"
col nonequijoin_preds for 99999999 head "Nonquijoin|preds"
col range_preds for 99999999 head "Range|preds"
col like_preds for 99999999 head "Like|preds"
col null_preds for 99999999 head "Null|preds"
col timestamp for a20 head "Timestamp"
col indexed for a8 head "Indexed|column"
col usage_report for a80


prompt
prompt **************************************************
prompt NOTE: If table is new run
prompt exec dbms_stats.flush_database_monitoring_info
prompt to refresh col usage statistics
prompt **************************************************
prompt
prompt Enter table owner
accept l_town prompt 'Table Owner:'
prompt
prompt Enter table name 
accept l_tablename prompt 'Table name:'

prompt
prompt **************************************************
prompt Table column statistics
prompt If none shown, make sure table was analyzed 
prompt with a valid column method option
prompt **************************************************
prompt

select owner, table_name, last_analyzed, column_name, histogram, 
to_char(sample_size) sample_size, 
num_distinct, num_nulls, num_buckets,
user_stats, avg_col_len 
from dba_tab_col_statistics
where owner = ('&&l_town')
and table_name = ('&&l_tablename')
order by column_name
/


prompt
prompt **************************************************
prompt Column usage stats
prompt These are possible candidates for histograms 
prompt and indices, if not already created
prompt **************************************************
prompt

/*
select c.owner, c.table_name, c.column_name
,a.equality_preds, a.equijoin_preds 
,a.nonequijoin_preds, a.range_preds, a.like_preds 
,a.null_preds, a.timestamp 
from sys.col_usage$ a ,dba_objects b ,dba_tab_cols c
where b.object_id = a.obj#
and c.owner = b.owner
and c.table_name = b.object_name
and a.intcol# = c.internal_column_id
and b.object_type = 'TABLE'
and b.owner = ('&&l_town')
and b.object_name = ('&&l_tablename')
order by owner ,table_name ,column_name
/
*/

with tmp as(select distinct column_name
from dba_ind_columns
where table_owner = ('&&l_town')
and table_name = ('&&l_tablename')),
tmp2 as (select column_name, histogram 
from dba_tab_col_statistics
where table_name = ('&&l_tablename')
and owner = ('&&l_town'))
select c.owner, c.table_name, c.column_name
,a.equality_preds, a.equijoin_preds 
,a.nonequijoin_preds, a.range_preds, a.like_preds 
,a.null_preds, a.timestamp
,decode(nvl(tmp.column_name,'0'),'0','NO','YES') indexed
,nvl(tmp2.histogram,'NO') histogram
from sys.col_usage$ a ,dba_objects b ,dba_tab_cols c, tmp, tmp2
where b.object_id = a.obj#
and c.owner = b.owner
and c.table_name = b.object_name
and a.intcol# = c.internal_column_id
and c.column_name = tmp.column_name(+)
and c.column_name = tmp2.column_name(+)
and b.object_type = 'TABLE'
and b.owner = ('&&l_town')
and b.object_name = ('&&l_tablename')
order by owner ,table_name ,column_name
/

prompt
prompt **************************************************
prompt Column usage stats
prompt using Oracle's report_col_usage
prompt **************************************************
prompt

select 
dbms_stats.report_col_usage(('&&l_town'),('&&l_tablename')) usage_report
from dual
/



