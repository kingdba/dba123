--##################################
--Level 3 script - Parameter history
--##################################

--Scope: DB time, wait class

clear col brea comp
set linesize 200
set pagesize 1000

prompt
prompt ###################################
prompt This SQL is AWR based
prompt GDTS Retention is 42 days
prompt To search further into the past use	
prompt OEM's Configuration History report
prompt ###################################
prompt
prompt
accept l_param prompt 'Parameter name [sga_target]:' default 'sga_target'
prompt

col parameter_name format a20 head "Parameter|name"
col instance_number for 99 head "Inst|Id"
col first_seen format a30 head "First|seen"
col latest_seen format a30 head "Last|seen"
col value format a80 head "Parameter|Value"

brea on paralmeter_name

select a.parameter_name, a.instance_number, to_char(a.value) value, min(b.end_interval_time) first_seen, max(b.end_interval_time) latest_seen
from dba_hist_parameter a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and parameter_name = ('&&l_param')
group by a.parameter_name, a.instance_number, to_char(a.value)
order by 4
/