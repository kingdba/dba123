--#######################
--Level 3 script - Events
--#######################

--Scope: DB time, wait event detail

clear col bre comp

set linesize 200
set pagesize 1000

column event format a30
column program format a40
column module format a40
column sql_id format a15
column ash_secs format 99999999

bre on event

prompt Enter instance number (default 1) 
prompt
accept l_inst prompt 'Instance number [1]:' default 1
prompt Enter wait event
prompt example: direct path read
prompt
accept l_wevent prompt 'Wait event:' 
prompt
prompt Enter start and end dates. Format DD-MON-YYYY hh24
prompt Example: 01-SEP-2015 14
accept l_start prompt 'Start date:'
accept l_end prompt 'End date:'

select --+parallel(a,8,1)
event, program, module, sql_id, sum(10) ash_secs
from dba_hist_active_sess_history a
where event = '&&l_wevent'            
and sample_time >= to_date(('&&l_start')||':00:00','DD-MON-YYYY hh24:mi:ss') 
and sample_time <= to_date(('&&l_end')||':00:00','DD-MON-YYYY hh24:mi:ss')
group by event, program, module, sql_id
--having sum(10) >= 60
order by event, ash_secs desc
/
