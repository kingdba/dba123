clear col bre comp

col owner for a20
col object_name for a30
col analyze_time for a20
col rowcnt for 99999999999
col s_date noprint

prompt Enter table owner
accept l_town prompt 'Table Owner:'
prompt
prompt Enter table name 
accept l_tablename prompt 'Table name:'
prompt

select a.owner, a.object_name, to_char(b.analyzetime,'DD-MON-YYYY hh24') analyze_time, b.rowcnt,
to_date(to_char(b.analyzetime,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24') s_date 
from dba_objects a, sys.wri$_optstat_tab_history b
where a.object_name = ('&&l_tablename')
and a.object_id = b.obj#
and a.object_type = 'TABLE'
and a.owner = ('&&l_town')
union
select owner, table_name, to_char(last_analyzed,'DD-MON-YYYY hh24'), num_rows, 
to_date(to_char(last_analyzed,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24')
from dba_tables
where table_name = ('&&l_tablename')
and owner = ('&&l_town')
order by s_date
/
