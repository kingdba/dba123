--########################
--Level 2 script - DBTime
--########################

--Scope: current day DB Time for all hosted databases

clear col bre comp

column s_time format a15 heading "Month of|Year"
column entity_name format a10 heading "Entity|Name"
column db_time_secs format 99.99 heading "DbTime|secs"
column avg_user_cpu_time_pct format 99.99 heading "Avg user|cpu t%"
column user_wait_time_pct format 99.99 heading "Avg user|wait t%"
column adm format 99.99 heading "Admin"
column app format 99.99 heading "App"
column cs format 99.99 heading "Cluster"
column cm format 99.99 heading "Commit"
column cr format 99.99 heading "Concurrency"
column cfg format 99.99 heading "Conf"
column id format 99.99 heading "Idle"
column net format 99.99 heading "Network"
column ot format 99.99 heading "Other"
column qu format 99.99 heading "Queueing"
column sch format 99.99 heading "Scheduler"
column sio format 99.99 heading "System I/O"
column uio format 99.99 heading "User I/O"

break on entity_name

set linesize 200
set pagesize 1000

prompt
prompt ############################
prompt Level 2 - DBt daily report
prompt ############################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt
prompt Enter Database name.
prompt Example: pjdel
prompt
accept l_dbname prompt 'Database name:'

select substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,to_char(collection_time,'DD-MON-YYYY hh24') s_time
,avg(case when metric_column_name = 'dbtime_ps' then value/100 end) db_time_secs
,avg(case when metric_column_name = 'avg_user_cpu_time_pct' then value end) avg_user_cpu_time_pct
,avg(case when metric_column_name = 'user_wait_time_pct' then value end) user_wait_time_pct
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Administrative' then value end) adm
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Application' then value end) app
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Cluster' then value end) cs
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Commit' then value end) cm
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Concurrency' then value end) cr
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Configuration' then value end) cfg
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Idle' then value end) id
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Network' then value end) net
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Other' then value end) ot
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Queueing' then value end) qu
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'Scheduler' then value end) sch
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'System I/O' then value end) sio
,avg(case when metric_column_name = 'dbtime_waitclass_pct' and key_part_1 = 'User I/O' then value end) uio
from  sysman.gc$metric_values a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and a.entity_name like ('&&l_dbname%')
and b.host_name = ('&&l_hostname')
and metric_group_name  in ('instance_throughput','wait_bottlenecks','wait_sess_cls')
and metric_column_name in ('dbtime_ps','avg_user_cpu_time_pct','user_wait_time_pct','dbtime_waitclass_pct')
and collection_time >=  trunc(sysdate)
group by to_char(collection_time,'DD-MON-YYYY hh24'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), db_time_secs desc
/
