--#######################
--Level 3 script - AWR
--#######################

--Scope: SQL, ASH waits break for SQL
clear col
clear brea
clear comp
set linesize 200
set pagesize 1000

prompt Enter sql_id 
prompt
accept l_sqlid prompt 'SQL Id:' 
prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

col source for a5 head "Source"
col sql_id for a20 head "Sql|Id"
col plan_hash_value for a10 head "Plan|hash|value"
col session_state for a20 head "Session|state"
col wait_class for a20 head "Wait|class"
col event for a40 head "Event"
col sql_plan_line_id for 9999 head "Sql Plan|Line id"
col sql_plan_operation for a20 head "SQl Plan|Operation"
col ash_secs for 99999 head "ASH Secs"

break on source on sql_id on plan_hash_value ski 1

--for 11g replace sql_full_plan_hash_value with sql_plan_hash_value

select 'ASH' source, sql_id, to_char(sql_full_plan_hash_value) plan_hash_value, session_state, wait_class, event, sql_plan_line_id, sql_plan_operation, sum(1) ash_secs
from  gv$active_session_history
where trunc(sample_time) >= trunc (sysdate-&&l_days)
and sql_id = ('&&l_sqlid')
having sum(1) >= 60
group by sql_id, sql_full_plan_hash_value, session_state, wait_class, event, sql_plan_line_id, sql_plan_operation
union all
select --+parallel(a,8,1)
'AWR', sql_id, to_char(sql_full_plan_hash_value) plan_hash_value, session_state, wait_class, event, sql_plan_line_id, sql_plan_operation, sum(10) ash_secs
from  dba_hist_active_sess_history a
where trunc(sample_time) >= trunc (sysdate-&&l_days)
and sql_id = ('&&l_sqlid')
having sum(10) >= 60
group by sql_id, sql_full_plan_hash_value, session_state, wait_class, event, sql_plan_line_id, sql_plan_operation
order by source, ash_secs desc
/