--#################################
--Level 2 script - IO exadata Cell
--#################################

--Scope: hourly metrics for exadata storage per database

clear col bre comp
 
set linesize 200
set pagesize 1000

col name for a5 head "Cell|group" justify left
col make_model for a15 head "Make|Model" justify left
col num_cells for 99 head "Number|of|Cells" justify left
col metric_history_days for 99 head "Metric|History|Days" justify left
col cpu_count for 9999 head "Total|CPU" justify left
col max_pd_iops for 9999999999 head "Physical|disk IOPS|Capacity" justify left
col max_fd_iops for 9999999999 head "Flash|Disk IOPS|Capacity" justify left
col disk_read_iops for 99999999 head "Disk|Read IOPS|Real Time" justify left justify left
col disk_write_iops for 99999999 head "Disk|Write IOPS|Real Time" justify left
col flash_read_iops for 99999999 head "Flash|Read IOPS|Real Time" justify left
col flash_write_iops for 99999999 head "Flash|Write IOPS|Real Time" justify left
col total_disk_iops for 99999999 head "Total|Disk IOPS|Real Time" justify left
col total_flash_iops for 99999999 head "Total|Flash IOPS|Real Time" justify left
col pd_pct for 999 head "Disk|Cap%" justify left
col fd_pct for 999 head "Flash|Cap%" justify left 
col c_time for a12 head "Collection|Timestamp" justify left
col hd_cel_load for 999999 head "Disk|Load" justify left
col hd_cel_util for 999 head "Disk|Util%" justify left
col fd_cel_load for 999999 head "Flash|Load" justify left
col fd_cel_util for 999 head "Flash|Util%" justify left

col target_name for a20 head "Target|Name"
col avg_io_load for 99.00 head "Avg|IO Load"
col max_io_load for 99.00 head "Max|IO Load"
col avg_iops for 9999.99 head "Avg|IOPS"
col max_iops for 9999.99 head "Max|IOPS"

prompt
prompt ############################
prompt Level 2 - Cell Hourly report
prompt ############################
prompt
prompt Enter exadata cell cluster name below. 
prompt Example: xeg2celadm
prompt
accept l_cellname prompt 'Host name:'
prompt
prompt
prompt ############################
prompt
prompt In addition, database metrics are provided for Oracle ASM and all other databases in a metric named�_OTHER_DATABASE_
prompt ASM is a special database indicator for ASM-initiated and related tasks, like rebalancing.
prompt _OTHER_DATABASE_ is used for databases that are not explicitly mentioned in the interdatabase IORM plan
prompt _OTHER_DATABASE_ may also include IO tasks not directly related to IO on behalf of the compute layer. 
prompt An example of _OTHER_DATABASE_ IO is the destaging of Write-back Flash cache data to disk.
prompt
prompt ############################
prompt

break on s_time skip page

-- current
-- samples every 15 min (4 x hour x storage_cell_count)

select to_char(collection_time,'DD-MON-YYYY hh24') s_time, key_part_1 target_name 
,round(avg(case when metric_column_label = 'I/O Requests per Second (IO/Sec)' then value end),2) avg_iops
,round(max(case when metric_column_label = 'I/O Requests per Second (IO/Sec)' then value end),2) max_iops
,round(avg(case when metric_column_label = 'Average I/O Load' then value end),2) avg_io_load
,round(max(case when metric_column_label = 'Average I/O Load' then value end),2) max_io_load
--,round(avg(case when metric_column_label = 'I/O Utilization (%)' then value end),2) pct
from sysman.gc$metric_values
where metric_group_name = 'IORMDB_Metric'
and metric_column_label in ('Average I/O Load','I/O Requests per Second (IO/Sec)','I/O Utilization (%)' )
and collection_time >=  trunc(sysdate)
and entity_name like '&&l_cellname%'
group by key_part_1, to_char(collection_time,'DD-MON-YYYY hh24')
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), avg_iops desc
/


