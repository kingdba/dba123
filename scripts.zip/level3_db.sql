--#######################
--Level 3 script - DBTime
--#######################

--Scope: Daily DB time metrics

clear col
clear brea
clear comp
set linesize 200
set pagesize 1000

col s_time for a11 head "Day of|Month" justify left
col admin for a8 head "Admin"
col app for a8 head "App"
col cls for a8 head "Cluster"
col commit for a8 head "Commit"
col concurrency for a8 head "Cncrcy"
col configuration for a8 head "config"
col idle for a8 head "Idle"
col net for a8 head "Network"
col other for a8 head "Other"
col sio for a8 head "System|I/O"
col uio for a8 head "User|I/O"
col cpu for a8 head "CPU +|CPU Wait"

prompt Enter instance number (default 1, 0 for all instances)
prompt
accept l_inst prompt 'Instance number [1]:' default 1
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42


select --+parallel(b,8,1) 
s_time
,to_char(avg(case when wait_class = 'Administrative' then ash_secs end)) admin
,to_char(avg(case when wait_class = 'Application' then ash_secs end)) app
,to_char(avg(case when wait_class = 'Cluster' then ash_secs end)) cls
,to_char(avg(case when wait_class = 'Commit' then ash_secs end)) commit
,to_char(avg(case when wait_class = 'Concurrency' then ash_secs end)) concurrency
,to_char(avg(case when wait_class = 'Configuration' then ash_secs end)) configuration
,to_char(avg(case when wait_class = 'Idle' then ash_secs end)) idle
,to_char(avg(case when wait_class = 'Network' then ash_secs end)) net
,to_char(avg(case when wait_class = 'Other' then ash_secs end)) other
,to_char(avg(case when wait_class = 'System I/O' then ash_secs end)) sio
,to_char(avg(case when wait_class = 'User I/O' then ash_secs end)) uio
,to_char(avg(case when wait_class is null then ash_secs end)) cpu
from (select to_char(sample_time,'DD-MON-YYYY') s_time, wait_class, sum(10) ash_secs
from dba_hist_active_sess_history b
where (instance_number = &&l_inst or &&l_inst = 0)
and trunc(sample_time) >= trunc(sysdate - &&l_days)
and dbid = (select dbid from v$database)
group by to_char(sample_time,'DD-MON-YYYY'), wait_class)
group by s_time
order by to_date(s_time,'DD-MON-YYYY')
/


