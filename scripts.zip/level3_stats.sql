cl scr
clear col brea comp
set feedback off
set linesize 200 
set pagesize 1000

col version for a10 head "Database|Version"
col client_name for a35
col status for a10
col job_status for a10
col job_start_t for a20
col job_duration for a20
col job_info for a70
col window_name for a16
col enabled for a7
col repeat_interval for a70
col duration for a14
col resource_plan for a25
col log_date for a20
col job_name for a25
col run_duration for a15
col additional_info for a70
col sname for a40
col value for a30
col incremental for a15
col granularity for a15
col publish for a10
col stale_percent for a5
col estimate_percent for a30
col cascade for a25
col method_opt for a30
col is_sap_db for a8 head "SAP DB"
col operation format a30
col target for a60
col start_time for a35
col end_time for a35
col autotask_status for a15
col window_group_name for a25
col enabled for a8
col windows for 99
col next_start_date for a50
col comments for a40
col instance_number for 99
col l_snap_endtime for a30
col attribute_name for a30

select version 
from v$instance;

prompt
prompt
prompt ######################################################################
prompt GDTS out of the box --> All Enabled
prompt Autotask Clients:
prompt   Stats must be enabled in non SAP
prompt   Advisors may be disabled.
prompt Autotask Task: 
prompt   should show one line per enabled client 
prompt   if no rows, Global Autotask may be disabled 
prompt   autotask_status should read ENABLED
prompt   Global Autotask can also be enabled using OEM
prompt   Administration --> Oracle Scheduler --> Automated Maintenance Tasks
prompt ######################################################################
prompt

prompt
prompt Autotask Clients
prompt

select client_name, status
from dba_autotask_client
/

prompt
prompt
prompt Autotask Task
prompt

select client_name, status
from dba_autotask_task
/

select window_name, autotask_status 
from 
dba_autotask_window_clients
/

prompt
prompt
prompt #################################################
prompt Windows status
prompt 10g windows must be disabled in 11g
prompt Resource Plan OK to be DEFAULT_MAINTENANCE_PLAN
prompt Also OK if null (disabled)
prompt Make sure next run is properly scheduled
prompt #################################################
prompt

select a.status, c.window_name, c.enabled, c.duration, c.repeat_interval, c.resource_plan
from dba_autotask_client a, dba_scheduler_wingroup_members b, dba_scheduler_windows c
where a.client_name='auto optimizer stats collection'
and a.window_group=b.window_group_name
and b.window_name=c.window_name
order by decode(c.window_name, 'MONDAY_WINDOW', 1 ,'TUESDAY_WINDOW',2, 'WEDNESDAY_WINDOW',3,
'THURSDAY_WINDOW', 4,'FRIDAY_WINDOW', 5,'SATURDAY_WINDOW', 6,'SUNDAY_WINDOW',7)
/

select window_name, enabled
from dba_scheduler_windows
where window_name in ('WEEKNIGHT_WINDOW','WEEKEND_WINDOW') 
order by 1
/

select window_name, resource_plan 
from dba_scheduler_windows
/

select window_group_name, enabled, number_of_windows windows, next_start_date, comments 
from dba_scheduler_window_groups
order by 1
/

prompt
prompt
prompt ############
prompt Hist Control
prompt ############
prompt

select sname, nvl(to_char(sval1),spare4) value 
from sys.optstat_hist_control$
/

prompt
prompt
prompt Db Level Settings
prompt

select
  dbms_stats.get_prefs(pname=>'incremental') incremental,
  dbms_stats.get_prefs(pname=>'granularity') granularity,
  dbms_stats.get_prefs(pname=>'publish') publish,
  dbms_stats.get_prefs(pname=>'stale_percent') stale_percent,
  dbms_stats.get_prefs(pname=>'estimate_percent') estimate_percent,
  dbms_stats.get_prefs(pname=>'cascade') cascade,
  dbms_stats.get_prefs(pname=>'method_opt') method_opt
from dual
/

prompt
prompt
prompt ##############################################
prompt Dictionary and  fixed object stats
prompt Gather on Demand/ when required
prompt OK if no rows returned, but consider gathering
prompt ##############################################
prompt

select operation, 
start_time, end_time
from dba_optstat_operations
where operation in ('gather_dictionary_stats',
'gather_fixed_objects_stats',
'gather_system_stats')
order by 3
/

prompt
prompt
prompt ##########################
prompt Stats job log 11g - 7 days
prompt No rows OK if SAP database
prompt ##########################
prompt

select client_name, job_status, to_char(job_start_time,'DD-MON-YYYY hh24:mi') job_start_t, job_duration, job_info
from dba_autotask_job_history
where client_name like '%stats%'
and trunc(job_start_time) >= trunc (sysdate-7)
--and job_status = 'STOPPED'
order by job_start_time
/

prompt
prompt
prompt #################################
prompt Systats - should not be collected
prompt #################################
prompt

select pname, pval1 
from sys.aux_stats$ 
where sname = 'SYSSTATS_MAIN'
order by 2
/

prompt
prompt
prompt ###############################################
prompt Retention
prompt AWR should be 42 (interval is normally 1 hour)
prompt Stats history should be 30
prompt Job History should be 30
prompt ##############################################
prompt
prompt
prompt AWR
prompt

select to_char(snap_interval) interval,
to_char(retention) retention
from dba_hist_wr_control a
join v$database b
on a.dbid=b.dbid
/

prompt
prompt
prompt AWR Snap Time
prompt To check AWR collection is not stalled
prompt

select sysdate from dual;

select instance_number, max(end_time) l_snap_endtime
from sys.wrm$_snapshot_details
group by instance_number
order by instance_number
/

prompt
prompt
prompt Stats History
prompt

select dbms_stats.get_stats_history_retention
from dual
/

prompt
prompt
prompt Job History
prompt

select * 
from dba_scheduler_global_attribute 
where attribute_name='LOG_HISTORY'
/

set feedback on

