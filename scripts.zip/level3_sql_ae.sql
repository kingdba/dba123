clear col bre comp

set linesize 200
set pagesize 1000

prompt Enter sql_id 
prompt
accept l_sqlid prompt 'SQL Id:' 
prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42



col sql_id for a15 head sql_id
col s_time for a20 head snap_time
col executions for 9999999999 head sql_execs
col cpu_t for 9999999999 head cpu_secs

brea on sql_id ski 1

select sql_id, to_char(begin_interval_time,'DD-MON-YYYY') s_time, 
sum(executions_delta) executions,
round(sum(cpu_time_delta)/1000000,2) cpu_t
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and b.instance_number=b.instance_number
and a.sql_id = ('&&l_sqlid')
and trunc(b.end_interval_time) >= trunc (sysdate-&&l_days)
group by sql_id, to_char(begin_interval_time,'DD-MON-YYYY')
order by to_date(to_char(begin_interval_time,'DD-MON-YYYY'),'DD-MON-YYYY')
/





