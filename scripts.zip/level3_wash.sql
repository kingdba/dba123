--#######################
--Level 3 script - DBTime
--#######################

--Scope: ASH, wait class history

set linesize 200
set pagesize 1000

col stime format a15
col wait_class for a15
col ash_secs for 99999999

break on stime skip page

prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

select --+parallel(b,8,1)
to_char(sample_time,'DD-MON-YYYY') stime, nvl(wait_class,'CPU + Wait CPU') wait_class, 
sum(10) ash_secs
from  dba_hist_active_sess_history 
where sample_time >= trunc (sysdate-&&l_days)
group by to_char(sample_time,'DD-MON-YYYY'), wait_class
order by to_date(to_char(sample_time,'DD-MON-YYYY'), 'DD-MON-YYYY'), ash_secs desc
/
