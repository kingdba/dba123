col sid for a20
col inst_id for 99
col id1 for 9999999999
col id2 for 9999999999
col lmode for a15
col request for 9999999999
col type for a20

select substr(decode(request,0,'holder: ','waiter: ')||sid,1,20) sid, inst_id, id1, id2, 
decode(lmode,0,'none', 1,'null (NULL)', 2,'row-S (SS)', 3,'row-X (SX)', 4,'share (S)', 5,'S/Row-X (SSX)', 6,'exclusive (X)', lmode) lmode,
decode(request,0,'none', 1,'null (NULL)', 2,'row-S (SS)', 3,'row-X (SX)', 4,'share (S)', 5,'S/Row-X (SSX)', 6,'exclusive (X)', request) request,
decode(type, 'TM','DML enqueue', 'TX','Transaction enqueue', 'UL','User supplied',type) type
from gv$lock
where (id1, id2, type) in (select id1, id2, type from gv$lock where request>0)
order by id1, request
/



