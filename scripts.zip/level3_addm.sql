--#######################
--Level 3 script - DBTime
--#######################

--Scope: ADDM Advisor top findings

column message format a80
column action_message format a80 wrapped
column times_found format 9999999999

prompt
accept l_days prompt 'Days in the past [lower(AWR,7)]:' default 7


select * from (
select count(*) times_found, b.message, c.message action_message 
from dba_advisor_tasks a, dba_advisor_findings b,
dba_advisor_actions c, dba_advisor_recommendations d
where a.owner=b.owner 
and a.task_id=b.task_id
and b.task_id=d.task_id 
and b.finding_id=d.finding_id
and a.task_id=c.task_id 
and d.rec_id=c.rec_id
and a.task_name like 'ADDM%' and a.status='COMPLETED'
and a.task_id in (select task_id from dba_advisor_executions
where execution_start >= trunc(sysdate - &&l_days))
group by b.message, c.message
order by 1 desc)
where rownum <= 20
/
