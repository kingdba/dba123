--#################################
--Level 2 script - IO exadata Cell
--#################################

--Scope: daily metrics for exadata storage

clear col bre comp comp
 
set linesize 200
set pagesize 1000

col name for a5 head "Cell|group" justify left
col make_model for a15 head "Make|Model" justify left
col num_cells for 99 head "Number|of|Cells" justify left
col metric_history_days for 99 head "Metric|History|Days" justify left
col cpu_count for 9999 head "Total|CPU" justify left
col max_pd_iops for 9999999999 head "Physical|disk IOPS|Capacity" justify left
col max_fd_iops for 9999999999 head "Flash|Disk IOPS|Capacity" justify left
col disk_read_iops for 99999999 head "Disk|Read IOPS|Real Time" justify left justify left
col disk_write_iops for 99999999 head "Disk|Write IOPS|Real Time" justify left
col flash_read_iops for 99999999 head "Flash|Read IOPS|Real Time" justify left
col flash_write_iops for 99999999 head "Flash|Write IOPS|Real Time" justify left
col total_disk_iops for 99999999 head "Total|Disk IOPS|Real Time" justify left
col total_flash_iops for 99999999 head "Total|Flash IOPS|Real Time" justify left
col pd_pct for 999 head "Disk|Cap%" justify left
col fd_pct for 999 head "Flash|Cap%" justify left 
col c_time for a12 head "Collection|Timestamp" justify left
col hd_cel_load for 999999 head "Disk|Load" justify left
col hd_cel_util for 999 head "Disk|Util%" justify left
col fd_cel_load for 999999 head "Flash|Load" justify left
col fd_cel_util for 999 head "Flash|Util%" justify left


prompt
prompt ############################
prompt Level 2 - Cell Daily report
prompt ############################
prompt
prompt Enter exadata cell cluster name below. 
prompt Example: xeg2celadm
prompt
accept l_cellname prompt 'Host name:'
prompt
prompt Enter start and end dates. Format MON-YYYY
prompt Example: 01-SEP-2015
accept l_start prompt 'Start date:'
accept l_end prompt 'End date:'

break on target_name

select substr(entity_name,1,4) target_name, to_char(collection_time,'DD-MON-YYYY') s_time 
,round(sum(case when metric_column_label = 'Read IOPS' and key_part_1 like 'CD%' then avg_value end)) disk_read_iops
,round(sum(case when metric_column_label = 'Write IOPS' and key_part_1 like 'CD%' then avg_value end)) disk_write_iops
,round(sum(case when metric_column_label = 'Read IOPS' and key_part_1 like 'FD%' then avg_value end)) flash_read_iops
,round(sum(case when metric_column_label = 'Write IOPS' and key_part_1 like 'FD%' then avg_value end)) flash_write_iops
,round(avg(case when metric_column_label = 'IO Load' and key_part_1 like 'CD%' then avg_value end)) hd_cel_load
,round(avg(case when metric_column_label = 'IO Utilization' and key_part_1 like 'CD%' then avg_value end)) hd_cel_util
,round(avg(case when metric_column_label = 'IO Load' and key_part_1 like 'FD%' then avg_value end)) fd_cel_load
,round(avg(case when metric_column_label = 'IO Utilization' and key_part_1 like 'FD%' then avg_value end)) fd_cel_util
from sysman.gc$metric_values_daily
where metric_group_name = 'CellDisk_Metric'
and metric_column_label in ('Read IOPS','Write IOPS','IO Load','IO Utilization' )
and collection_time >=  to_date(('&&l_start')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < to_date(('&&l_end')||'00:00:00','DD-MON-YYYY hh24:mi:ss')
and entity_name like '&&l_cellname%'
group by to_char(collection_time,'DD-MON-YYYY'), substr(entity_name,1,4)
order by to_date(to_char(collection_time,'DD-MON-YYYY'),'DD-MON-YYYY')
/
