clear bre comp col

col wait_class for a20
col event for a50 heading "Event|Name"
col wcnt for 9999999999 heading "Wait|Count"
col tms for 9999999999 heading "Time|Waited(ms)"
col avg_ms for 99999 heading "Average|Time(ms)"
col tmsf for 9999999999 heading "Fgnd Time|Waited(ms)"
col avg_msf for 99999 heading "Fgnd Average|Time(ms)"
col num_sess_waiting for 9999999 head "Sessions|waiting"

break on wait_class skip 1

--11g+

select b.wait_class, 
b.name event, 
a.num_sess_waiting,
a.wait_count wcnt,
a.time_waited*10 tms,
nvl(round(a.time_waited*10/nullif(a.wait_count,0),3),0) avg_ms,
a.time_waited_fg*10 tmsf,
nvl(round(a.time_waited_fg*10/nullif(a.wait_count_fg,0),3),0) avg_msf
from v$eventmetric a,v$event_name b
where a.event_id=b.event_id
--and b.wait_class in ('User I/O','System I/O')
and b.wait_class != 'Idle'
--and a.wait_count > 100
and a.time_waited > 0
order by b.wait_class, wait_count desc
/
