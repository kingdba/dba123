--#######################
--Level 3 script - AWR
--#######################

--Scope: SQL, history of binds for SQL

clear col bre comp

set linesize 200
set pagesize 1000

prompt Enter sql_id 
prompt
accept l_sqlid prompt 'SQL Id:' 
prompt

col bind for a10 head "Bind|name"
col bind_string for a50 head "Bind value|side #s are|delimiters"
col datatype_string for a40 head "Data|type"
col times_parsed for 99999 head "Times|parsed|in AWR"
col value_anydata for a40 head "Value|Anydata|ts binds"

select name bind, '#'||nvl(value_string,'<null>')||'#'bind_string, datatype_string, anydata.accesstimestamp(value_anydata) value_anydata, count(*) times_parsed
from dba_hist_sqlbind
where sql_id = ('&&l_sqlid')
group by name, value_string, datatype_string, anydata.accesstimestamp(value_anydata)
order by name, times_parsed desc
/