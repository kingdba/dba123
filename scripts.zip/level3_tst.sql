clear col bre comp
col tsname for a20 head "Tablespace|name"
col pr for 9999999999999999999 head "Physical|Reads"
col pw for 9999999999999999999 head "Physical|Writes"
col avr_delta for 999.99 head "Avg read|time(ms)"
col avw_delta for 999.99 head "Avg write|time(ms)"

select tsname, sum(phyrds) pr, sum(phywrts) pw, (sum(readtim)*10)/sum(phyrds) avr_delta, (sum(writetim)*10)/sum(phywrts) avw_delta 
from dba_hist_snapshot a, dba_hist_filestatxs b
where a.snap_id = b.snap_id
and a.instance_number=b.instance_number
and b.instance_number = 1
and a.begin_interval_time >= (select startup_time+1/24 from v$instance)
group by tsname
order by 2 desc
/

