--##############
--Level 1 script
--##############

--NOTE: the script can take from 30 seconds to 2 minutes to run as it has to mine millions of rows
--Scope: Daily report for a given month

prompt
prompt ########################
prompt Level 1 - Hourly Report
prompt ########################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt Enter Day of Month. Format DD-MON-YYYY
prompt Example: 01-SEP-2015
accept l_myear prompt 'Day of Month:'

set linesize 200
set pagesize 1000


col s_time for a15 head "Day of|Month" justify left
col avg_cpu_usage_pct for 999 head "Avg CPU|Usage %" justify left
col max_cpu_usage_pct for 999 head "Max CPU|Usage %" justify left
col avg_cpu_load for 99.99 head "Avg CPU|Load" justify left
col max_cpu_load for 99.99 head "Max CPU|Load" justify left
col avg_cpu_io_wait_pct for 99.99 head "Avg CPU|IO Wait%" justify left
col max_cpu_io_wait_pct for 99.99 head "Max CPU|IO Wait%" justify left
col avg_mem_usage_pct for 999 head "Avg Mem|Usage%" justify left
col max_mem_usage_pct for 999 head "Max Mem|Usage%" justify left
col avg_mem_hp_pct for 999 head "Avg Mem|+HP %" justify left
col hp_free for 999999 head "HPages|Mb Free" justify left
col hp_pct for 99.9 head "HPages %|of RAM" justify left
col ora_pct for 999 head "Orcl %|of RAM" justify left
col ora_mb for 99999999 head "Oracle|Memory MB|(sga.sh)" justify left
col mem for 99999999 head "Total|RAM Mb" justify left
col avg_swap_utilization_pct for 99.99 head "Avg Swp|Usage %" justify left
col max_swap_utilization_pct for 99.99 head "Max Swp|Usage %" justify left
col avg_number_of_processes for 99999 head "Avg|procs" justify left
col max_number_of_processes for 99999 head "Max|procs" justify left
col db_cnt for 999 head "Num|DBs" justify left
col db_allocated_gb for 999999 head "DB|Alloc|Gb" justify left
col db_used_gb for 999999 head "DB|Used|Gb" justify left
col db_time_secs for 999.99 head "DbTime|secs" justify left
col avg_io_sec for 99999 head "Avg DB|IO sec" justify left
col max_io_sec for 99999 head "Max DB|IO sec" justify left
col avg_io_mb_sec for 99999 head "Avg IO|Mb sec" justify left
col max_io_mb_sec for 9999999 head "Max IO|Mb sec" justify left
col avg_db_blk_sec for 99999999 head "Avg blkchg|per sec" justify left
col avg_pr_ps for 9999999 head "Avg Ph|Rds sec" justify left
col max_pr_ps for 9999999 head "max Ph|Rds sec" justify left
col avg_pw_ps for 999999 head "Avg Ph|Wrs sec" justify left
col max_pw_ps for 999999 head "Max Ph|Wrs sec" justify left
col instance_mem_gb for 999.99 head "Inst|Mem Gb" justify left
col mem_util for 999 head "Total Mem|Util %" justify left
col avg_instance_cores for 99.99 head "Avg DB|Cores" justify left
col max_instance_cores for 99.99 head "Max DB|Cores" justify left
col host_name for a15 head "Host|Name"
col total_cpu_cores for a15 head "CPU|Cores"
col logical_cpu_count for a15 head "CPU|Logical"
col mem for a8 head "Total|RAM Mb"
col avg_aas for 999 head "Avg|AAS" justify left
col avg_com_ps for 99999 head "Avg cmit|per sec" justify left
col avg_netm_ps for 99.99 head "Avg Net|Mb sec" justify left
col avg_redo_ps for 99.99 head "Avg Rdo|MB sec" justify left
col avg_rollback_ps for 999 head "Avg Rbs|per sec" justify left
col avg_log_mem_pct for 99,99 head "Avg|Lmem|used %" justify left
col max_log_mem_pct for 99,99 head "Max|Lmem|used %" justify left
col avg_active_logical_mem for 9999 head "Avg|act|Lmem Gb" justify left
col max_active_logical_mem for 9999 head "Max|act|Lmem Gb" justify left
col os_summary for a90 head "OS|Summary" justify left
col virtual for a7 head "Virtual|Box" justify left

prompt
prompt #########
prompt Host Info
prompt #########

select substr(host_name,1, instr(host_name,'.')-1) host_name, 
--virtual, 
to_char(mem) mem, 
case when virtual = 'Yes' and os_summary like 'AIX%' then (select value from sysman.mgmt_ecm_hw_virtual where name = 'Online Virtual CPUs' and ecm_snapshot_id =  a.snapshot_guid) 
else to_char(total_cpu_cores) end total_cpu_cores, 
case when virtual = 'Yes' and os_summary like 'AIX%' then (select value from sysman.mgmt_ecm_hw_virtual where name = 'Type' and ecm_snapshot_id =  a.snapshot_guid) 
else to_char(logical_cpu_count) end logical_cpu_count, os_summary
from sysman.mgmt$os_hw_summary a where host_name = ('&&l_hostname')
/ 

prompt 
prompt #############
prompt Capacity Info
prompt #############

--Level 1 SQL


with host_util as (select --+materialize
to_char(collection_time,'DD-MON-YYYY hh24') s_time
,avg(case when metric_column_name = 'cpuUtil' then avg_value end) avg_cpu_usage_pct
,max(case when metric_column_name = 'cpuUtil' then max_value end) max_cpu_usage_pct
,avg(case when metric_column_name = 'cpuLoad' then avg_value end) avg_cpu_load
,max(case when metric_column_name = 'cpuLoad' then max_value end) max_cpu_load
,avg(case when metric_column_name = 'cpuIOWait' then avg_value end) avg_cpu_io_wait_pct
,max(case when metric_column_name = 'cpuIOWait' then max_value end) max_cpu_io_wait_pct
,avg(case when metric_column_name = 'memUsedPct' then avg_value end) avg_mem_usage_pct
,max(case when metric_column_name = 'memUsedPct' then max_value end) max_mem_usage_pct
,avg(case when metric_column_name = 'usedLogicalMemoryPct' then avg_value end) avg_log_mem_pct
,max(case when metric_column_name = 'usedLogicalMemoryPct' then max_value end) max_log_mem_pct
,avg(case when metric_column_name = 'activeLogicalMem' then avg_value/1024/1024 end) avg_active_logical_mem
,max(case when metric_column_name = 'activeLogicalMem' then max_value/1024/1024 end) max_active_logical_mem
,avg(case when metric_column_name = 'mem_util' then avg_value end) avg_mem_hp_pct
,avg(case when metric_column_name = 'Value' and key_part_1='Huge MB' then avg_value end) hp_set
,avg(case when metric_column_name = 'Value' and key_part_1='Avail Huge MB' then avg_value end) hp_free
,avg(case when metric_column_name = 'Value' and key_part_1='ORA Pct' then avg_value end) ora_pct
,avg(case when metric_column_name = 'Value' and key_part_1='ORA MB' then avg_value end) ora_mb
,avg(case when metric_column_name = 'swapUtil' then avg_value end) avg_swap_utilization_pct
,max(case when metric_column_name = 'swapUtil' then max_value end) max_swap_utilization_pct
,avg(case when metric_column_name = 'noOfProcs' then avg_value end) avg_number_of_processes
,max(case when metric_column_name = 'noOfProcs' then max_value end) max_number_of_processes
from sysman.gc$metric_values_hourly
where entity_name = ('&&l_hostname') 
and metric_group_name in ('Load','ME$sga.sh','ME$Memory_Utilization_Linux_HP')
and metric_column_name in ('cpuUtil','cpuIOWait','cpuLoad','memUsedPct','swapUtil','noOfProcs','memUsedPct','Value','mem_util','usedLogicalMemoryPct','activeLogicalMem')
and collection_time >=  to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss')+1
group by to_char(collection_time,'DD-MON-YYYY hh24')
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24')),
--###DB and Instance Metrics
db_th as (select --+materialize
s_time, count(entity_name) db_cnt, sum(db_allocated_gb) db_allocated_gb, 
sum(db_used_gb) db_used_gb, sum(instance_mem_gb) instance_mem_gb, 
sum(avg_instance_cores) avg_instance_cores, sum(max_instance_cores) max_instance_cores, 
sum(db_time_secs) db_time_secs, 
sum(avg_io_sec) avg_io_sec, sum(max_io_sec) max_io_sec,
sum(avg_io_mb_sec) avg_io_mb_sec, sum(max_io_mb_sec) max_io_mb_sec, 
sum(avg_db_blk_sec) avg_db_blk_sec, 
sum(avg_pr_ps) avg_pr_ps, sum(max_pr_ps) max_pr_ps,
sum(avg_pw_ps) avg_pw_ps, sum(max_pw_ps) max_pw_ps,
sum(avg_aas) avg_aas,
sum(avg_com_ps) avg_com_ps,
sum(avg_netm_ps) avg_netm_ps,
sum(avg_redo_ps) avg_redo_ps,
sum(avg_rollback_ps) avg_rollback_ps
from (
--instance level subquery (Level 2). Mind db_time is centiseconds per second
select /*+ full(@GMVD val) parallel(@GMVD val,8)*/ to_char(collection_time,'DD-MON-YYYY hh24') s_time, nvl(substr(a.entity_name,1,instr(a.entity_name,'.')-1), a.entity_name ) entity_name
,avg(case when metric_column_name = 'ALLOCATED_GB' then avg_value end) db_allocated_gb
,avg(case when metric_column_name = 'USED_GB' then avg_value end) db_used_gb
,avg(case when metric_column_name = 'total_memory' then avg_value/1024 end) instance_mem_gb
,avg(case when metric_column_name = 'cpuusage_ps' then avg_value/100 end) avg_instance_cores
,max(case when metric_column_name = 'cpuusage_ps' then max_value/100 end) max_instance_cores --NOTE: all instances max at same time
,avg(case when metric_column_name = 'dbtime_ps' then avg_value/100 end) db_time_secs
,avg(case when metric_column_name = 'iorequests_ps' then avg_value end) avg_io_sec
,max(case when metric_column_name = 'iorequests_ps' then max_value end) max_io_sec
,avg(case when metric_column_name = 'iombs_ps' then avg_value end) avg_io_mb_sec
,max(case when metric_column_name = 'iombs_ps' then max_value end) max_io_mb_sec
,avg(case when metric_column_name = 'dbblkchanges_ps' then avg_value end) avg_db_blk_sec
,avg(case when metric_column_name = 'physreads_ps' then avg_value end) avg_pr_ps
,max(case when metric_column_name = 'physreads_ps' then max_value end) max_pr_ps
,avg(case when metric_column_name = 'physwrites_ps' then avg_value end) avg_pw_ps
,max(case when metric_column_name = 'physwrites_ps' then max_value end) max_pw_ps
,avg(case when metric_column_name = 'avg_active_sessions' then avg_value end) avg_aas
,avg(case when metric_column_name = 'commits_ps' then avg_value end) avg_com_ps
,avg(case when metric_column_name = 'networkbytes_ps' then avg_value/1024/1024 end) avg_netm_ps
,avg(case when metric_column_name = 'redosize_ps' then avg_value/1024/1024 end) avg_redo_ps
,avg(case when metric_column_name = 'rollbacks_ps' then avg_value end) avg_rollback_ps
from sysman.gc$metric_values_hourly a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
--and a.entity_name like 'AW2_429%'
and b.host_name = ('&&l_hostname')
and metric_group_name in ('DATABASE_SIZE','memory_usage','instance_throughput','instance_efficiency')
and metric_column_name in ('ALLOCATED_GB','USED_GB','total_memory','cpuusage_ps','dbtime_ps','iorequests_ps','iombs_ps','dbblkchanges_ps','physreads_ps','physwrites_ps',
'avg_active_sessions','commits_ps','networkbytes_ps','redosize_ps','rollbacks_ps')
and collection_time >=  to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < to_date(('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss')+1
group by to_char(collection_time,'DD-MON-YYYY hh24'), nvl(substr(a.entity_name,1,instr(a.entity_name,'.')-1), a.entity_name)
order by to_date(to_char(collection_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24'), entity_name)
group by s_time
order by to_date(s_time,'DD-MON-YYYY hh24'))
--Main SQL
select /*+ full(@SEL$10 val) parallel(@SEL$10 val,8) */
a.s_time, 
a.avg_cpu_usage_pct, 
a.max_cpu_usage_pct,
--a.avg_cpu_io_wait_pct, 
--a.max_cpu_io_wait_pct,
a.avg_cpu_load,
a.max_cpu_load,
--a.avg_mem_usage_pct,
--a.max_mem_usage_pct,
a.avg_active_logical_mem,
a.avg_log_mem_pct,
--a.max_log_mem_pct,
--a.avg_mem_hp_pct, 
--a.ora_pct, 
--a.hp_free, 
--hp_set * 100 / (100 * (a.ora_mb + a.hp_free)/a.ora_pct) hp_pct,
a.avg_swap_utilization_pct,  
--a.max_swap_utilization_pct,
a.avg_number_of_processes,
--a.max_number_of_processes, 
--b.db_cnt, 
--b.db_allocated_gb, 
--b.instance_mem_gb, 
b.db_time_secs,
b.avg_aas,
b.avg_instance_cores,
--b.max_instance_cores,
b.avg_io_sec,
--b.max_io_sec,
b.avg_io_mb_sec,
--b.max_io_mb_sec, 
b.avg_pr_ps,
--b.max_pr_ps,
b.avg_pw_ps,
--b.max_pw_ps
b.avg_com_ps,
b.avg_netm_ps,
b.avg_redo_ps,
b.avg_rollback_ps
from host_util a, db_th b
where a.s_time=b.s_time(+)
order by to_date(a.s_time,'DD-MON-YYYY hh24')
/

