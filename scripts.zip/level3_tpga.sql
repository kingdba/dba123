clear col brea comp
set linesize 200
set pagesize 1000

prompt
prompt ######################################################################
prompt PGA AWR current utilisation (since instance startup)
prompt ######################################################################
prompt

col inst_id for 99
col pgasetmb for 99999999
col pgacurmb for 99999999
col pgamaxmb for 99999999


select inst_id,
  max(case when name ='aggregate PGA target parameter' then round(value/1024/1024) end) pgasetMB,
  max(case when name ='total PGA allocated' then round(value/1024/1024) end) pgacurMB,
  max(case when name ='maximum PGA allocated' then round(value/1024/1024) end) pgamaxMB
  from gv$pgastat
  where name in ('aggregate PGA target parameter','total PGA allocated','maximum PGA allocated')
  group by inst_id
order by 1, 2, 3, 4
/

prompt
prompt
prompt ######################################################################
prompt PGA max utilisation (AWR)
prompt ######################################################################
prompt

clear col brea comp
break on instance_number ski 1
col name for a30
col avg_mb for 99999999
col max_mb for 99999999

select instance_number, name, avg(value)/1024/1024 avg_Mb, max(value)/1024/1024 max_Mb
from dba_hist_pgastat
where name in ('total PGA allocated','maximum PGA allocated')
group by instance_number, name
order by 1,2,3, 4
/

prompt
prompt
prompt ######################################################################
prompt PGA daily utilisation (AWR) - "total PGA allocated"
prompt ######################################################################
prompt 

clear col brea comp
break on instance_number ski 1
col instance_number for 99
col s_time for a15
col max_mb for 99999999

select a.instance_number, to_char(a.end_interval_time,'DD-MON-YYYY') s_time, max(value)/1024/1024 max_Mb
from dba_hist_snapshot a, dba_hist_pgastat b
where a.snap_id = b.snap_id
and a.instance_number=b.instance_number
and name = 'total PGA allocated'
group by a.instance_number, to_char(a.end_interval_time,'DD-MON-YYYY')
order by instance_number, to_date(to_char(a.end_interval_time,'DD-MON-YYYY'),'DD-MON=YYYY')
/

prompt
prompt
prompt ######################################################################
prompt Daily TOP PGA SLQs - PGA >= 512M
prompt ######################################################################
prompt

clear col brea comp
break on s_time ski 1
col s_time format a20
col session_id format 99999
col session_serial# format 99999999
col pga_allocated_mb format 99999 
col temp_space_mb format 99999 
col sql_id format a20
col sql_plan_hash_value form 9999999999
col module format a30


prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42
prompt Enter PGA threshold in Mb (default 512)
prompt
accept l_pgamem prompt 'PGA Mem:' 
prompt

select /*+ opt_param('optimizer_index_cost_adj',10000) full(a) parallel(a,8,1)  */ 
to_char(sample_time, 'DD-MON-YYYY') s_time, sql_id,
max(pga_allocated)/1024/1024 pga_allocated_mb, max(temp_space_allocated)/1024/1024 temp_space_mb
from dba_hist_active_sess_history a
where trunc(sample_time) >= trunc(sysdate - &&l_days)
and is_sqlid_current='Y'
and sql_id is not null
and dbid = (select dbid from v$database)
group by to_char(sample_time, 'DD-MON-YYYY'), sql_id
having max(pga_allocated)/1024/1024 >= &&l_pgamem
order by to_date(to_char(sample_time, 'DD-MON-YYYY'),'DD-MON-YYYY'), pga_allocated_mb desc
/

