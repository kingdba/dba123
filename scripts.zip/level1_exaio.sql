--Level 1 exadata hosts I/O metrics
--Run in OEM

prompt
prompt ########################################
prompt Exadata Sorage Cells current I/O metrics
prompt ########################################
prompt

col name for a5 head "Cell|group" justify left
col make_model for a15 head "Make|Model" justify left
col num_cells for 99 head "Number|of|Cells" justify left
col metric_history_days for 99 head "Metric|History|Days" justify left
col cpu_count for 9999 head "Total|CPU" justify left
col max_pd_iops for 9999999999 head "Physical|disk IOPS|Capacity" justify left
col max_fd_iops for 9999999999 head "Flash|Disk IOPS|Capacity" justify left
col disk_read_iops for 99999999 head "Disk|Read IOPS|Real Time" justify left justify left
col disk_write_iops for 99999999 head "Disk|Write IOPS|Real Time" justify left
col flash_read_iops for 99999999 head "Flash|Read IOPS|Real Time" justify left
col flash_write_iops for 99999999 head "Flash|Write IOPS|Real Time" justify left
col total_disk_iops for 99999999 head "Total|Disk IOPS|Real Time" justify left
col total_flash_iops for 99999999 head "Total|Flash IOPS|Real Time" justify left
col pd_pct for 999 head "Disk|Cap%" justify left
col fd_pct for 999 head "Flash|Cap%" justify left 
col c_time for a12 head "Collection|Timestamp" justify left
col hd_cel_load for 999999 head "Disk|Load" justify left
col hd_cel_util for 999 head "Disk|Util%" justify left
col fd_cel_load for 999999 head "Flash|Load" justify left
col fd_cel_util for 999 head "Flash|Util%" justify left

with tmp as(select substr(target_name,1,4) target_name
,round(sum(case when column_label = 'Read IOPS' and key_value like 'CD%' then value end)) disk_read_iops
,round(sum(case when column_label = 'Write IOPS' and key_value like 'CD%' then value end)) disk_write_iops
,round(sum(case when column_label = 'Read IOPS' and key_value like 'FD%' then value end)) flash_read_iops
,round(sum(case when column_label = 'Write IOPS' and key_value like 'FD%' then value end)) flash_write_iops
,round(avg(case when column_label = 'IO Load' and key_value like 'CD%' then value end)) hd_cel_load
,round(avg(case when column_label = 'IO Utilization' and key_value like 'CD%' then value end)) hd_cel_util
,round(avg(case when column_label = 'IO Load' and key_value like 'FD%' then value end)) fd_cel_load
,round(avg(case when column_label = 'IO Utilization' and key_value like 'FD%' then value end)) fd_cel_util
,to_char(max(collection_timestamp),'DD-MON hh24:mi') c_time
from sysman.mgmt$metric_current
where metric_name = 'CellDisk_Metric'
and column_label in ('Read IOPS','Write IOPS','IO Load','IO Utilization' )
group by substr(target_name,1,4)),
tmp2 as (select substr(name,1,4) name, substr(make_model,instr(make_model,'High'),length(make_model)) make_model, 
count(name) num_cells , sum(cpu_count) cpu_count, sum(max_pd_iops) max_pd_iops, sum(max_fd_iops) max_fd_iops, avg(metric_history_days) metric_history_days
from sysman.em_exadata_cell a, sysman.mgmt_ecm_gen_snapshot b
where a.ecm_snapshot_id = b.snapshot_guid
and b.is_current = 'Y'
group by substr(name,1,4), substr(make_model,instr(make_model,'High'),length(make_model)))
select tmp2.name, tmp2.make_model, tmp2.num_cells, tmp2.cpu_count,
tmp.disk_read_iops, tmp.disk_write_iops, tmp.disk_read_iops+tmp.disk_write_iops total_disk_iops, tmp2.max_pd_iops,
(tmp.disk_read_iops+tmp.disk_write_iops) * 100 / tmp2.max_pd_iops pd_pct,
tmp.flash_read_iops, tmp.flash_write_iops,tmp.flash_read_iops + tmp.flash_write_iops total_flash_iops, tmp2.max_fd_iops,
(tmp.flash_read_iops + tmp.flash_write_iops) * 100 / tmp2.max_fd_iops fd_pct, tmp.hd_cel_load, tmp.hd_cel_util, tmp.fd_cel_load, tmp.fd_cel_util, tmp.c_time,  tmp2.metric_history_days
from tmp, tmp2
where tmp.target_name  = tmp2.name
order by tmp.target_name
/
