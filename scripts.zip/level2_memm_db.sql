--###################################
--Level 2 script - Memory and DB Size
--###################################

--Scope: Monthly Memory and DB Size metrics per hosted instance

clear col bre comp

bre on entity_name

column s_time format a10 heading "Month of|Year" justify left
column entity_name format a20 heading "Instance|name" justify left
col db_allocated_gb for 9999999 head "DB Alloc|Gb" justify left
col db_used_gb for 9999999 head "DB Used|Gb" justify left
col instance_mem_gb for 999.99 head "Inst|Mem Gb" justify left

set linesize 200
set pagesize 1000

prompt
prompt ########################################
prompt Level 2 - Mem and DB size monthly report
prompt ########################################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'

prompt
prompt Enter start and end dates. Format DD-MON-YYYY
prompt Example: 01-SEP-2015
accept l_start prompt 'Start date:'
accept l_end prompt 'End date:'
prompt
prompt Enter db name below.
prompt Example: pcrmn
accept l_dbame prompt 'DB name:'

select substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,to_char(collection_time,'MON-YYYY') s_time 
,avg(case when metric_column_name = 'ALLOCATED_GB' then avg_value end) db_allocated_gb
,avg(case when metric_column_name = 'USED_GB' then avg_value end) db_used_gb
,avg(case when metric_column_name = 'total_memory' then avg_value/1024 end) instance_mem_gb
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and a.entity_name like '&&l_dbame%'
and b.host_name = ('&&l_hostname')
and metric_group_name in ('DATABASE_SIZE','memory_usage')
and metric_column_name in ('ALLOCATED_GB','USED_GB','total_memory')
and collection_time >=  to_date(('&&l_start')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < to_date(('&&l_end')||'00:00:00','DD-MON-YYYY hh24:mi:ss')
group by to_char(collection_time,'MON-YYYY'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by to_date(to_char(collection_time,'MON-YYYY'),'MON-YYYY'), instance_mem_gb desc
/
