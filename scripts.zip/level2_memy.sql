--###################################
--Level 2 script - Memory and DB Size
--###################################

--Scope: Yearly Memory and DB Size metrics per hosted instance

clear col bre comp

break on s_time skip page

column s_time format a10 heading "Month of|Year" justify left
column entity_name format a20 heading "Instance|name" justify left
col db_allocated_gb for 9999999 head "DB Alloc|Gb" justify left
col db_used_gb for 9999999 head "DB Used|Gb" justify left
col instance_mem_gb for 999.99 head "Inst|Mem Gb" justify left

set linesize 200
set pagesize 1000

prompt
prompt #######################################
prompt Level 2 - Mem and DB size yearly report
prompt #######################################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt

select substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,avg(case when metric_column_name = 'ALLOCATED_GB' then avg_value end) db_allocated_gb
,avg(case when metric_column_name = 'USED_GB' then avg_value end) db_used_gb
,avg(case when metric_column_name = 'total_memory' then avg_value/1024 end) instance_mem_gb
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and b.host_name = ('&&l_hostname')
and metric_group_name in ('DATABASE_SIZE','memory_usage')
and metric_column_name in ('ALLOCATED_GB','USED_GB','total_memory')
and collection_time >= add_months(trunc(sysdate,'MM'),-12 )
group by substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by instance_mem_gb desc
/
