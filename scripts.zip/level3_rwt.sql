--#######################
--Level 3 script - AWR
--#######################

--Scope: Tablespace Read/Write times

clear col bre comp

prompt Enter instance number (default 1) 
prompt
accept l_inst prompt 'Instance number [1]:' default 1
promp
prompt Enter tablespace name (default SYSTEM) 
prompt
accept l_tsname prompt 'Tablespace Name:' default SYSTEM
prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

col s_time for a20 head "Snapshot|time"
col tsname for a15 head "Tablespace|name"
col phyrds for 9999999999 head "Physical|reads"
col pr_delta for 9999999999 head "Physical|reads|delta"
col readtim for 9999999999 head "Read|Time|100s"
col rt_ms for 999.99 head "Avg read|time(ms)"
col phywrts for 9999999999 head "Physical|writes"
col pw_delta for 9999999999 head "Physical|writes|delta"
col writetim for 9999999999 head "Write|Time|100s"
col wt_ms for 999.99 head "Avg write|time(ms)"

brea on tsname

prompt
prompt #########################################
prompt Estimated Read/Write Times for tablespace
prompt #########################################
prompt

select tsname, s_time, 
pr_delta, (rt_delta*10)/pr_delta rt_ms,
pw_delta, (wt_delta*10)/pw_delta wt_ms
from (
  select tsname, s_time, phyrds, 
  phyrds-lag(phyrds) over (partition by tsname order by s_time) pr_delta,
  readtim-lag(readtim) over (partition by tsname order by s_time) rt_delta,
  phywrts-lag(phywrts) over (partition by tsname order by s_time) pw_delta,
  writetim-lag(writetim) over (partition by tsname order by s_time) wt_delta
  from
    (select tsname, to_char(begin_interval_time,'DD-MON-YYYY hh24') s_time, 
    sum(phyrds) phyrds, sum(readtim) readtim , sum(readtim)*10/sum(phyrds) rt_ms,
    sum(phywrts) phywrts, sum(writetim) writetim, sum(writetim)*10/sum(phywrts) wt_ms
    from dba_hist_snapshot a, dba_hist_filestatxs b
    where a.snap_id = b.snap_id
    and a.instance_number=b.instance_number
    and b.instance_number = (&&l_inst)
    and b.dbid in (select dbid from v$database)
    and a.begin_interval_time >= trunc (sysdate-&&l_days)
    and tsname = ('&&l_tsname')
    group by tsname, to_char(begin_interval_time,'DD-MON-YYYY hh24')
    order by tsname, to_date(to_char(begin_interval_time,'DD-MON-YYYY hh24'),'DD-MON-YYYY hh24')
  )
)
where pr_delta is not null
/
