--########################
--Level 2 script - I/O
--########################

--Scope: daily I/O metrics per hosted instance

clear col bre comp

col s_time for a11 head "Day of|Month" justify left
break on s_time skip page

column entity_name format a20 heading "Instance|name" justify left
col avg_io_sec for 99999 head "Avg DB |IO sec" justify left
col max_io_sec for 9999999 head "Max DB |IO sec" justify left
col avg_io_mb_sec for 99999 head "Avg IO|Mb sec" justify left
col max_io_mb_sec for 999999999 head "Max IO|Mb sec" justify left
col avg_pr_ps for 9999999 head "Avg Ph|Rds sec" justify left
col max_pr_ps for 999999999 head "max Ph|Rds sec" justify left
col avg_pw_ps for 999999 head "Avg Ph|Wrs sec" justify left
col max_pw_ps for 99999999 head "Max Ph|Wrs sec" justify left
col avg_bc_ps for 999999 head "Avg blk|chg sec" justify left
col max_bc_ps for 99999999 head "Max blk|chg sec" justify left
col avg_net_ps for 999999 head "Avg Net|bytes sec" justify left
col max_net_ps for 99999999 head "Max Net|bytes sec" justify left


--compute sum of avg_io_sec on s_time
--compute sum of max_io_sec on s_time
--compute sum of max_pr_ps on s_time
--compute sum of max_pw_ps on s_time
--compute sum of max_bc_ps on s_time

set linesize 200
set pagesize 1000

prompt
prompt ############################
prompt Level 2 - IO Daily report
prompt ############################
prompt
prompt Enter fully qualified host name below. 
prompt Example: xeg1client01.admin.cargill.com
prompt
accept l_hostname prompt 'Host name:'
prompt
prompt Enter month and year. Format MON-YYYY
prompt Example: SEP-2015
accept l_myear prompt 'Month and Year:'

select to_char(collection_time,'DD-MON-YYYY') s_time, substr(a.entity_name,1,instr(a.entity_name,'.')-1) entity_name
,avg(case when metric_column_name = 'iorequests_ps' then avg_value end) avg_io_sec
,max(case when metric_column_name = 'iorequests_ps' then max_value end) max_io_sec
,avg(case when metric_column_name = 'iombs_ps' then avg_value end) avg_io_mb_sec
,max(case when metric_column_name = 'iombs_ps' then max_value end) max_io_mb_sec
,avg(case when metric_column_name = 'physreads_ps' then avg_value end) avg_pr_ps
,max(case when metric_column_name = 'physreads_ps' then max_value end) max_pr_ps
,avg(case when metric_column_name = 'physwrites_ps' then avg_value end) avg_pw_ps
,max(case when metric_column_name = 'physwrites_ps' then max_value end) max_pw_ps
,avg(case when metric_column_name = 'dbblkchanges_ps' then avg_value end) avg_bc_ps
,max(case when metric_column_name = 'dbblkchanges_ps' then max_value end) max_bc_ps
--,avg(case when metric_column_name = 'networkbytes_ps' then avg_value end) avg_net_sec
--,max(case when metric_column_name = 'networkbytes_ps' then max_value end) max_net_sec
from sysman.gc$metric_values_daily a, sysman.gc_manageable_entities b
where a.entity_name=b.entity_name
and a.entity_type = b.entity_type
and a.entity_type = 'oracle_database'
and b.host_name = ('&&l_hostname')
and metric_group_name = 'instance_throughput'
and metric_column_name in ('iorequests_ps','iombs_ps','physreads_ps','physwrites_ps','dbblkchanges_ps','networkbytes_ps')
and collection_time >=  to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss') 
and collection_time < add_months(to_date('01'||('&&l_myear')||'00:00:00','DD-MON-YYYY hh24:mi:ss'),1)
group by to_char(collection_time,'DD-MON-YYYY'), substr(a.entity_name,1,instr(a.entity_name,'.')-1)
order by to_date(to_char(collection_time,'DD-MON-YYYY'),'DD-MON-YYYY'), avg_io_sec desc
/
