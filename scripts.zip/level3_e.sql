--#######################
--Level 3 script - DBTime
--#######################

--Scope: DB time, wait event

clear col
clear brea
clear comp
set linesize 200
set pagesize 1000

col sort0 noprint
col day for a10 head "Hour of|Day"
col name for a35 head "Event|Name"
col value for 99999999 head "Seconds|Waited"

col rtr for 990.00 head "% of total"
col ratio for a15 head "Histogram"

break on report
compute sum of value on report

prompt Enter instance number (default 1, 0 for all instances)
prompt
accept l_inst prompt 'Instance number [1]:' default 1 
prompt Enter wait event
prompt example: direct path read
prompt
accept l_wevent prompt 'Wait event:' 
prompt
prompt Enter days in the past (default lower(AWR retention,42)) 
prompt
accept l_days prompt 'Days in the past [lower(AWR,42)]:' default 42

select sort0, day, name, round(value) value
,substr(nvl(rpad('+', round((ratio_to_report(value) over (partition by name)*100)/2, 0), '+'),'+'),1,15) ratio
from (select sort0, day, name, sum(value)/1000000 value
      from (select to_char(b.end_interval_time, 'YYYYMMDD') sort0, to_char(b.end_interval_time, 'DD-MON') day, a.event_name name,
            nvl(decode(greatest(a.time_waited_micro, nvl(lag(a.time_waited_micro) 
            over (partition by a.dbid, a.instance_number, a.event_name order by a.snap_id),0)),
            a.time_waited_micro, a.time_waited_micro-lag(a.time_waited_micro) 
            over (partition by a.dbid, a.instance_number, a.event_name order by a.snap_id), a.time_waited_micro), 0) value
            from dba_hist_system_event a, dba_hist_snapshot b
            where a.event_name = '&&l_wevent'
            and b.snap_id = a.snap_id
            and b.dbid = a.dbid
            and b.instance_number = a.instance_number
            and (a.instance_number = &&l_inst or &&l_inst = 0)
            and b.end_interval_time >= sysdate -&&l_days
           )
      group by sort0, day, name
      --having sum(value)/1000000 >= 3600
      )
order by sort0, name
/

