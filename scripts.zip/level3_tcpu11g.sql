--Level 3 top CPU
--11g ONLY

prompt
prompt #######################
prompt Top 10 CPU AWR monthly
prompt #######################
prompt

clear columns
clear computes
clear breaks

--Scope: SQL, top cpu

col s_time for a12 head "Month of|Year" justify left
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|secs"

--col rnk for 99 head "Group|Ranking"
col rnk noprint

break on s_time ski page

select * from (
select to_char(begin_interval_time, 'MON-YYYY') s_time, sql_id
, sum(cpu_time_delta)/1000000 cpu_time
, sum(buffer_gets_delta) buff_gets
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, rank() over (partition by to_char(begin_interval_time, 'MON-YYYY') order by sum(cpu_time_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
--and begin_interval_time between to_date('07-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') 
--and to_date('14-JUL-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') --date filter
group by to_char(begin_interval_time, 'MON-YYYY'), sql_id
having sum(cpu_time_delta) > 0
order by to_date(to_char(begin_interval_time, 'MON-YYYY'),'MON-YYYY'), cpu_time desc)
where rnk <=10
/

prompt
prompt ###########################
prompt Top 10 CPU AWR last 7 days
prompt ###########################
prompt

col s_time for a12 head "Day of|Month" justify left

select * from (
select to_char(begin_interval_time, 'DD-MON-YYYY') s_time, sql_id
, sum(cpu_time_delta)/1000000 cpu_time
, sum(buffer_gets_delta) buff_gets
, sum(disk_reads_delta) disk_reads
, sum(physical_read_requests_delta) ph_reads 
, rank() over (partition by to_char(begin_interval_time, 'DD-MON-YYYY') order by sum(cpu_time_delta) desc) rnk
from dba_hist_sqlstat a, dba_hist_snapshot b
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
and begin_interval_time >= trunc(sysdate)-7
group by to_char(begin_interval_time, 'DD-MON-YYYY'), sql_id
having sum(cpu_time_delta) > 0
order by to_date(to_char(begin_interval_time, 'DD-MON-YYYY'),'DD-MON-YYYY'), cpu_time desc)
where rnk <=10
/


prompt
prompt ############################
prompt Last 7 Days Top 10 CPU - ASH
prompt ############################
prompt

col program for a40
col module for a40
col ash_secs for 9999999999

select --+parallel(a,8)
* from (
select program, module, sql_id, sum(10) ash_secs
from dba_hist_active_sess_history a
where session_state = 'ON CPU'
and sample_time >= trunc(sysdate -7)
group by program, module, sql_id
order by ash_secs desc)
where rownum <= 10
/


prompt
prompt #########################
prompt Top 10 CPU - Cursor Cache
prompt #########################
prompt


clear col brea comp

col inst_id for 99 head "Instance|number"
col sql_id for a20 head "Sql|id" justify left
col buff_gets for 999999999999 head "Buffer|Gets" justify left
col disk_reads for 999999999999 head "Disk|Reads" justify left
col ph_reads for 999999999999 head "Physical|Reads" justify left
col cpu_time for 999999999999 head "CPU|Secs"

break on instance_number skip 1

--Cursor Cache

select * from (select
sql_id
, sum(cpu_time)/1000000 cpu_time
, sum(buffer_gets) buff_gets
, sum(disk_reads) disk_reads
, sum(physical_read_requests) ph_reads 
from gv$sql
group by sql_id
order by cpu_time desc)
where rownum <=10
/


prompt
prompt ##################################
prompt Top 10 CPU - Active SQL Monitoring
prompt ##################################
prompt

col inst_id for 9999
col username for a15
col sid for 99999
col sql_id for a15
col buffer_gets for 999999999999999999
col cpu_secs for 99999.99
col disk_reads for 9999999999
col direct_writes for 9999999999
col physical_read_requests for 9999999999
col physical_write_requests for 9999999999

select * from (
select inst_id, username, sid, sql_id, buffer_gets, round(cpu_time/1000000,1) cpu_secs, 
disk_reads, direct_writes, physical_read_requests, physical_write_requests
from gv$sql_monitor
where status = 'EXECUTING'
order by cpu_secs desc)
where rownum <=10
/
