--Level 3
--Scope: exadata metrics - Exadata Databases ONLY

clear bre col comp
 
prompt
prompt ##################################
prompt Exadata estimated Flash efficiency
prompt ##################################
prompt
prompt AWR Metrics (mind cumulative)
prompt

col inst_id for 99 head "Instance|Number"
col s_time for a8
col phy_reads_total for 9999999999 head "Physical Reads|Total 10k"
col cell_read_hits for 9999999999 head "Cell Read|Hits 10k"
col phy_reads_opt for 9999999999 head  "Physical Read|Optimized 10k"
col phy_writes_total for 9999999999 head  "Physical Writes|Total 10k"
col phy_writes_opt for 9999999999 head  "Physical Writes|Optimized 10k"
col pct_reads_flash_hit for 999 head "Pct Reads|Flash Hit"
col pct_reads_flash_sindex for 999 head "Pct Flash|Storage Index"
col pct_writes_flash for 999 head  "Pct Writes|Flash Hit"
col rw for 999 head "Read to|Write ratio"
col sql_id for a20 head "SQL|Id"
col sql_text for a40 head "SQL|Text"
col physical_read_requests for 99999999 head "Physical R|Requests"
col optimized_phy_read_requests for 99999999 head "Optimized|Physical R|Requests"
col ohp for 9999999999 head "Optimized|Hit Pct"
col inst_id for 99 head "Inst|Id"
col stat_name for a10 head "Stat|name"
col stat_value for a10 head "Phys. I/O|Gb Saved"

-- Cell Flash Cache read hits�This records the number of read requests that found a match in the Exadata Smart Flash Cache.
-- Physical read requests optimized�This records the number of read requests that were �optimized� either by the 
-- Exadata Smart Flash Cache or through Storage Indexes.

select s_time, sum(phy_reads_total)/10000 phy_reads_total, 
sum(phy_cache_hits)/10000 cell_read_hits,
sum(phy_reads_cell)/10000 phy_reads_opt, 
sum(phy_writes_total)/10000 phy_writes_total, 
sum(phy_writes_cell)/10000 phy_writes_opt, 
round(sum(phy_cache_hits)*100/sum(phy_reads_total)) pct_reads_flash_hit, 
round(sum(phy_reads_cell)*100/sum(phy_reads_total)) pct_reads_flash_sindex, 
round(sum(phy_writes_cell)*100/sum(phy_writes_total)) pct_writes_flash,
round(sum(phy_reads_cell)*100/sum(phy_reads_total))/round(sum(phy_writes_cell)*100/sum(phy_writes_total)) rw
from (
  select a.instance_number, to_char(b.end_interval_time,'MON-YYYY') s_time 
  ,max(case when stat_name = 'cell flash cache read hits' then value end) phy_cache_hits 
  ,max(case when stat_name = 'physical read total IO requests' then value end) phy_reads_total
  ,max(case when stat_name = 'physical read requests optimized' then value end) phy_reads_cell
  ,max(case when stat_name = 'physical write total IO requests' then value end) phy_writes_total
  ,max(case when stat_name = 'physical write requests optimized' then value end) phy_writes_cell
  from dba_hist_sysstat a, dba_hist_snapshot b
  where a.snap_id = b.snap_id
  and a.instance_number = b.instance_number
  --and b.begin_interval_time between to_date('01-MAY-2015 00:00:00','DD-MON-YYYY hh24:mi:ss') 
  --and to_date('01-OCT-2015 00:00:00','DD-MON-YYYY hh24:mi:ss'
  and a.stat_name in ('cell flash cache read hits','physical read total IO requests','physical read requests optimized','physical write total IO requests','physical write requests optimized')
  group by to_char(b.end_interval_time,'MON-YYYY'), a.instance_number)
group by s_time
order by to_date(s_time,'MON-YYYY')
/

prompt
prompt ###################################
prompt Current Metrics (since last bounce)
prompt ###################################
prompt

select inst_id, phy_reads_total/10000 phy_reads_total, 
phy_cache_hits/10000 cell_read_hits,
phy_reads_cell/10000 phy_reads_opt, 
phy_writes_total/10000 phy_writes_total, 
phy_writes_cell/10000 phy_writes_opt, 
round(phy_cache_hits*100/phy_reads_total) pct_reads_flash_hit, 
round(phy_reads_cell*100/phy_reads_total) pct_reads_flash_sindex, 
round(phy_writes_cell*100/phy_writes_total) pct_writes_flash,
round(phy_reads_cell*100/phy_reads_total)/round(phy_writes_cell*100/phy_writes_total) rw
from (select inst_id
  ,max(case when name = 'cell flash cache read hits' then value end) phy_cache_hits 
  ,max(case when name = 'physical read total IO requests' then value end) phy_reads_total
  ,max(case when name = 'physical read requests optimized' then value end) phy_reads_cell
  ,max(case when name = 'physical write total IO requests' then value end) phy_writes_total
  ,max(case when name = 'physical write requests optimized' then value end) phy_writes_cell
  from gv$sysstat
where name in ('cell flash cache read hits','physical read total IO requests','physical read requests optimized','physical write total IO requests','physical write requests optimized')
group by inst_id)
order by inst_id
/

bre on inst_id ski 1

select inst_id, decode(b.name,
'cell physical IO bytes saved by storage index', 'Strge idx',
'cell physical IO interconnect bytes returned by smart scan', 'Smart Scan') stat_name,
to_char(round(value/1024/1024/1024)) stat_value
from gv$sysstat a, v$statname b
where a.statistic# = b.statistic#
and b.name in ('cell physical IO bytes saved by storage index',
'cell physical IO interconnect bytes returned by smart scan')
order by 1,2
/

prompt
prompt #####################
prompt Top 10 Optimized SQLs
prompt #####################
prompt

select sql_id,
sql_text,
physical_read_requests,
optimized_phy_read_requests,
ohp
from (select sql_id,
  substr(sql_text, 1, 40) sql_text,
  physical_read_requests,
  optimized_phy_read_requests,
  optimized_phy_read_requests*100/physical_read_requests ohp,
  rank() over(order by optimized_phy_read_requests desc) optimized_rank
from v$sql
where optimized_phy_read_requests > 0
order by optimized_phy_read_requests desc)
where optimized_rank <= 10
/
