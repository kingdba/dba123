set null ''

accept sql_id char prompt 'sql_id: '

clear col bre comp

brea on sql_id 

col sql_id for a15 head "SQL|id"
col plan_hash_value for 9999999999 head "Plan|Hash|Value"
col max_time for 9999999 head "Max|exec|time(s)"
col avg_time for 9999999 head "Avg|exec|time(s)"
col min_time for 9999999 head "Min|exec|time(s)"
col grt_avg for 99999 head "Exec|cnt|> avg"
col loweq_avg for 99999 head "Exec|cnt|<= avg"justify left
col exec_ids for 99999 head "Exec id|count"
col exec_ids for 99999 head "Exec id|count"
col pct_gt_avg for 99.99 head "Pct ids|> avg"
col pct_leq_avg for 99.99 head "Pct ids|<= avg"

select sql_id, plan_hash_value, max_time, avg_time, min_time, grt_avg, loweq_avg, grt_avg+loweq_avg exec_ids, 
round(grt_avg*100/(grt_avg+loweq_avg),2) pct_gt_avg,
round(loweq_avg*100/(grt_avg+loweq_avg),2) pct_leq_avg
from (
with tmp1 as(
select sql_id, plan_hash_value, max(ash_secs) max_time, avg(ash_secs) avg_time, min(ash_secs) min_time
from (select sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(1) ash_secs
from gv$active_session_history
where sql_id = '&sql_id'
group by sql_id, sql_plan_hash_value, sql_exec_id
union all
select --+parallel(a,8) 
sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(10) ash_secs
from dba_hist_active_sess_history a
where sql_id = '&sql_id'
group by sql_id, sql_plan_hash_value, sql_exec_id)
group by sql_id, plan_hash_value)
select tmp1.sql_id, tmp1.plan_hash_value, tmp1.max_time, tmp1.avg_time, tmp1.min_time,
   (select count(*) total
    from (select sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(1)
    from gv$active_session_history
    where sql_id = tmp1.sql_id
    and sql_plan_hash_value = tmp1.plan_hash_value
    group by sql_id, sql_plan_hash_value, sql_exec_id
    having sum(1) > tmp1.avg_time
    union all
    select --+parallel(a,8)
    sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(10)
    from dba_hist_active_sess_history a
    where sql_id = tmp1.sql_id
    and sql_plan_hash_value = tmp1.plan_hash_value
    group by sql_id, sql_plan_hash_value, sql_exec_id
    having sum(10) > tmp1.avg_time)
    group by sql_id, plan_hash_value) grt_avg,
    (select count(*) total
    from (select sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(1)
    from gv$active_session_history
    where sql_id = tmp1.sql_id
    and sql_plan_hash_value = tmp1.plan_hash_value
    group by sql_id, sql_plan_hash_value, sql_exec_id
    having sum(1) <= tmp1.avg_time
    union all
    select --+parallel(a,8)
    sql_id, sql_plan_hash_value plan_hash_value, sql_exec_id, sum(10)
    from dba_hist_active_sess_history a
    where sql_id = tmp1.sql_id
    and sql_plan_hash_value = tmp1.plan_hash_value
    group by sql_id, sql_plan_hash_value, sql_exec_id
    having sum(10) <= tmp1.avg_time)
    group by sql_id, plan_hash_value) loweq_avg
from tmp1)
/