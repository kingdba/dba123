--Level 3 segments that may benefit from move/rebuild if wasted space

prompt
prompt ###########################################################
prompt Segments that may benefit from move/rebuild if wasted space
prompt Focus on high waits and row lock contention  
prompt Run Manual Space Advisor if needed
prompt ##########################################################
prompt

clear col bre comp

col event for a35
col sql_id for a20
col owner for a20
col object_name for a30
col ash_secs for 999999999

prompt Enter schema Owner
prompt example: PRODDTA
prompt
accept l_owner prompt 'Schema Owner:' 
prompt

select * from 
(select --+parallel(a,8)
a.event, a.sql_id, b.owner, b.object_type, b.object_name, sum(10) ash_secs 
from dba_hist_active_sess_history a, dba_objects b
where wait_class = 'Application'
and a.current_obj# = b.object_id
--and b.object_type = 'INDEX'
and b.owner = '&&l_owner'
group by a.event, a.sql_id, b.owner, b.object_type, b.object_name
order by ash_secs desc)
where rownum <= 10
/

select * from 
(select --+parallel(a,8)
a.event, a.sql_id, b.owner, b.object_type, b.object_name, sum(10) ash_secs 
from dba_hist_active_sess_history a, dba_objects b
where wait_class = 'Cluster'
and a.current_obj# = b.object_id
--and b.object_type = 'INDEX'
and b.owner = '&&l_owner'
group by a.event, a.sql_id, b.owner, b.object_type, b.object_name
order by ash_secs desc)
where rownum <= 10
/

prompt
prompt #####################################
prompt Indices that may benefit from rebuild
prompt #####################################
prompt
 
col table_name for a30
col num_rows for 9999999999
col last_analyzed, for a20
col table_blocks for 99999999
col segment_name for a30
col segment_type for a15
col idx_blocks for 99999999
col leaf_blocks for 99999999
col clustering_factor for 9999999999

-- Clustering Factor
-- If the value is near the number of blocks, then the table is very well ordered. 
-- In this case, the index entries in a single leaf block tend to point to rows in the same data blocks.
-- If the value is near the number of rows, then the table is very randomly ordered. 
-- In this case, it is unlikely that index entries in the same leaf block point to rows in the same data blocks.


with tmp as (select --+materialize
owner, table_name, blocks, num_rows, last_analyzed
from dba_tables
where blocks >= 1280 and owner not in ('SYS','SYSTEM'))
select tmp.table_name, tmp.num_rows, tmp.blocks table_blocks, tmp.last_analyzed, a.segment_name, a.segment_type, a.blocks idx_blocks, b.leaf_blocks, b.clustering_factor
from dba_segments a, dba_indexes b, tmp 
where a.owner = tmp.owner
and b.owner = a.owner
and a.segment_name = b.index_name
and b.table_name = tmp.table_name
and a.segment_type = 'INDEX'
and b.owner = '&&l_owner'
--and b.table_name = 'POSICION'     
and a.blocks*100/decode(tmp.blocks,0,1,tmp.blocks) >= 80
--group by tmp.table_name, tmp.blocks, tmp.last_analyzed, a.segment_name, a.segment_type
--having sum(a.blocks)*100/decode(tmp.blocks,0,1,tmp.blocks) >= 80
order by 2 desc
/

col inst_id for 99
col sql_id for a15
col plan_hash_value for a20
col object_name for a30
col cardinality for 99
col operation for a20
col io_cost for 9999999999

select * from (
  select inst_id, sql_id, to_char(plan_hash_value) plan_hash_value, object_name, cardinality, io_cost, operation||' '||options operation
  from gv$sql_plan
  where operation = 'INDEX'
  and options = 'RANGE SCAN'
  and object_owner = '&&l_owner'
  and io_cost/decode(cardinality,0,1,cardinality) >= 100
  order by io_cost desc)
where rownum <= 10
/

