col target for a15 head "Target"
col mb_set for 99999999 head "Instance|setting (MB)"
col mb_current for 99999999 head "Actual|size (MB)"
col mb_max for 99999999 head "Max since last|bounce(MB)"

break on report

compute sum of Mb_Set on report
compute sum of Mb_Current on report
compute sum of Mb_Max on report

prompt
prompt ###################################################################
prompt Main Memory settings
prompt MISC-ESTIMATED is estimated footprint for non PGA process OS memory
prompt ###################################################################
prompt

select 'SGA' target, value/1024/1024 mb_set,  value/1024/1024 mb_current, value/1024/1024 mb_max
from v$parameter2
where name ='sga_max_size'
union all
select 'PGA',
       (select value/1024/1024 from v$pgastat where name in('aggregate PGA target parameter')),
       (select value/1024/1024 from v$pgastat where name in('total PGA inuse')),
       (select value/1024/1024 from v$pgastat where name in('maximum PGA allocated')) from dual
union all
select 'MISC-ESTIMATED', limit_value* 3976/1024, current_utilization* 3976/1024, max_utilization* 3976/1024 
from v$resource_limit 
where resource_name = 'processes'
/

prompt 
prompt #####################################
prompt Other related parameters and settings
prompt #####################################
prompt

column c1 format a35 heading "parameter|name"
column c2 format a12 heading "value|scope|memory"
column c3 format a8 heading "value|is|default"
column c4 format a20 heading "value|scope|spfile(sid)"

select a.name c1, a.value c2, a.isdefault c3, nvl(b.value, 'Not Set') || '(' ||b.sid ||')' c4
from v$system_parameter a, v$spparameter b
where a.name = b.name
and a.name in ('shared_pool_reserved_size','shared_pool_size','sga_target','sga_max_size',
'db_cache_size','streams_pool_size','memory_target','pga_aggregate_target',
'buffer_pool_keep','java_pool_size','olap_page_pool_size',
'log_buffer', 'use_large_pages','pga_aggregate_limit')
order by 1
/


prompt 
prompt #########
prompt SGA Info
prompt #########

clear col bre

col name for a40
col Mb for 99999999

select name, bytes/1024/1024 Mb
from v$sgainfo
order by 2 desc
/


prompt 
prompt #########################
prompt Actual Dynamic Allocation
prompt #########################

col inst_id for 99 head "Inst|id"
col component for a20 head "Component"
col Mb for 99999999 head "Actual|size(MB)"

brea on inst-id ski 1

select inst_id, component, round(current_size/1024/1024) Mb
from gv$sga_dynamic_components
where current_size!= 0
order by 1,2
/

prompt 
prompt ##########################
prompt Shared Pool top 5 (Actual)
prompt ##########################

col name for a30 heading "Pool"
col pool_Mb for 99999999 head "Pool|Mb"

select * from (
select name, bytes/1024/1024 pool_Mb 
from v$sgastat where pool = 'shared pool' order by pool_Mb desc)
where rownum <= 5
/

prompt 
prompt ###################
prompt PGA top 10 (Actual)
prompt ###################

clear col bre

col spid for 99999
col program for a30
col mb_max for 99999999
col mb_alloc for 99999999
col mb_used for 99999999
col mb_FREE for 99999999
col category for a10

select * from (
select spid, program, 
pga_max_mem /1024/1024 Mb_Max,
pga_alloc_mem /1024/1024 Mb_alloc,
pga_used_mem /1024/1024 Mb_used,
pga_freeable_mem /1024/1024 Mb_free
from v$process
order by Mb_alloc desc)
where rownum <=10
/


