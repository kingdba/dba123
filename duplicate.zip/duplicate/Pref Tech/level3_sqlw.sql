col inst head 'Act|Inst' justify left for a4
col srv head 'Act|Service' justify left for a8
col username head 'Parsing|user' justify left for a10
col load_time head 'First|load|time' justify left for a8
col l_load_time head 'Last|load|time' justify left for a8
col l_act_time head 'Last|Active|time' justify left for a8
col elapsed_t head 'Elapsed|Sec' justify left for a8
col cpu_t head 'Cpu|Sec' justify left for a8
col user_io head 'User IO|Wait|Sec' justify left for a8
col cluster_w justify left for a6 head "Crs|Sec" justify left for a5
col conc_s head 'Ccy|Sec' justify left for a5
col pl_s head 'Pl|Sec' justify left for a3
col app_s head 'App|Sec' justify left for a5
col java_s head 'Jav|Sec' justify left for a3
col Buf_Per_Rows head 'Buffer|per|Rows' justify left for a10
col Buf_Per_Exec head 'Buffer|per|Exec' justify left for a10
col Sec_Per_Exec head 'Sec|per|Exec' justify left for a8
col buffer_gets head 'Buffer|gets' justify left for a10
col rows_processed head 'Rows|Procssed' justify left for a8
col disk_r head 'Disk|reads' justify left for a8
col child for 999 head "Chld|Num" justify left
col executions for a8 head "Exec" justify left
col fetches for a5 head "Fetch" justify left
col plan_hash_value for a10 head "Plan|hash|value" justify left


accept sql_id char prompt 'sql_id: '

select to_char (inst_id) inst
,substr(username,1,10) username
--,sql_id
,child_number child
,to_char(plan_hash_value) plan_hash_value
,substr(first_load_time,6,8) load_time
,substr(last_load_time,6,8) l_load_time
,to_char(last_active_time,'MM-DD/hh24') l_act_time
,to_char(round(elapsed_time/1000000,2)) elapsed_t
,to_char(round(cpu_time/1000000, 2)) cpu_t
,to_char(round(user_io_wait_time/1000000, 2)) user_io
,to_char(round(cluster_wait_time/1000000, 2)) cluster_w
,to_char(round(concurrency_wait_time/1000000, 2)) conc_s
,to_char(round(plsql_exec_time/1000000, 2)) pl_s
,to_char(round(application_wait_time/1000000, 2)) app_s
,to_char(round(java_exec_time/1000000, 2)) java_s
,to_char(decode (rows_processed,0,buffer_gets,round(buffer_gets/rows_processed))) Buf_Per_Rows
,to_char(decode (executions,0,buffer_gets,round(buffer_gets/executions))) Buf_Per_Exec
,to_char(decode (executions,0,round(elapsed_time/1000000,2),round(elapsed_time/1000000/executions,4))) Sec_Per_Exec
,to_char(buffer_gets) buffer_gets
,to_char(rows_processed) rows_processed
,to_char(fetches) fetches
,to_char(executions) executions
,to_char(disk_reads) disk_r
--,upper(sql_text)
from gv$sql, dba_users where parsing_user_id = user_id
and sql_id = '&sql_id'
order by username, inst_id, l_act_time
/
